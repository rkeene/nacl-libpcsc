goog.provide('SmartCardClientApp.PinDialog.Server');

goog.require('GoogleSmartCard.ModalDialog.Server');
goog.require('goog.Promise');

goog.scope(function() {

/** @const */
var PIN_DIALOG_URL = 'pin-dialog.html';

/** @const */
var PIN_DIALOG_WINDOW_OPTIONS_OVERRIDES = {
  'innerBounds': {
    'width': 230
  }
};

/** @const */
var GSC = GoogleSmartCard;

/**
 * @return {!goog.Promise.<string>}
 */
SmartCardClientApp.PinDialog.Server.requestPin = function() {
  return GSC.ModalDialog.Server.runDialog(
      PIN_DIALOG_URL, PIN_DIALOG_WINDOW_OPTIONS_OVERRIDES);
}

});  // goog.scope
