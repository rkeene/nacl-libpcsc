// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// This file is a manually built replacement for the Autotools-generated config
// file.

#ifndef GOOGLE_SMART_CARD_THIRD_PARTY_CCID_CONFIG_H_
#define GOOGLE_SMART_CARD_THIRD_PARTY_CCID_CONFIG_H_

#include <errno.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

#endif  // GOOGLE_SMART_CARD_THIRD_PARTY_CCID_CONFIG_H_
