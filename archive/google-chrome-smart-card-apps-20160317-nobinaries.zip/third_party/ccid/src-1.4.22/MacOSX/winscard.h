#include <PCSC/winscard.h>
#include <PCSC/wintypes.h>
