/**
 * @fileoverview Main script of the PIN dialog window.
 *
 * Once the dialog is finished with some result (either sucessfully returning
 * data entered by user, or being canceled), it uses the methods of the
 * GoogleSmartCard.ModalDialog library for returning the result to the caller
 * window (i.e. to the App's background page).
 */

goog.provide('SmartCardClientApp.PinDialog.Main');

goog.require('GoogleSmartCard.Logging');
goog.require('GoogleSmartCard.ModalDialog.Client');
goog.require('goog.dom');
goog.require('goog.dom.forms');
goog.require('goog.events');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

function okClickListener() {
  var pin = goog.dom.forms.getValue(goog.dom.getElement('input'));
  GSC.ModalDialog.Client.resolveModalDialog(pin);
}

function cancelClickListener() {
  GSC.ModalDialog.Client.rejectModalDialog(new Error(
      'PIN dialog was canceled'));
}

goog.events.listen(goog.dom.getElement('ok'), 'click', okClickListener);
goog.events.listen(goog.dom.getElement('cancel'), 'click', cancelClickListener);

GSC.ModalDialog.Client.prepareAndShowModalDialog();

});  // goog.scope
