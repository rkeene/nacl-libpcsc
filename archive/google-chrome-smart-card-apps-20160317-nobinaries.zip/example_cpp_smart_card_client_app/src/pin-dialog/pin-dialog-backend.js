/**
 * @fileoverview Backend that handles PIN dialog requests received from the NaCl
 * module.
 */

goog.provide('SmartCardClientApp.PinDialog.Backend');

goog.require('GoogleSmartCard.ModalDialog.Server');
goog.require('GoogleSmartCard.RequestHandler');
goog.require('GoogleSmartCard.RequestReceiver');
goog.require('goog.Promise');
goog.require('goog.messaging.MessageChannel');
goog.require('goog.object');
goog.require('goog.promise.Resolver');

goog.scope(function() {

/** @const */
var REQUESTER_NAME = 'pin_dialog';

/** @const */
var PIN_MESSAGE_KEY = 'pin';

/** @const */
var PIN_DIALOG_URL = 'pin-dialog.html';

/** @const */
var PIN_DIALOG_WINDOW_OPTIONS_OVERRIDES = {
  'innerBounds': {
    'width': 230
  }
};

/** @const */
var GSC = GoogleSmartCard;

/**
 * Backend that handles PIN dialog requests received from the NaCl module.
 *
 * On construction, subscribes at the passed message channel for receiving
 * messages of the special type representing PIN requests.
 *
 * Once the message with the PIN request is received, opens the PIN dialog and,
 * once it finishes, sends its result as a message through the message channel.
 * @param {!goog.messaging.MessageChannel} naclModuleMessageChannel
 * @constructor
 */
SmartCardClientApp.PinDialog.Backend = function(naclModuleMessageChannel) {
  /** @private */
  this.chromeUsbRequestReceiver_ = new GSC.RequestReceiver(
      REQUESTER_NAME, naclModuleMessageChannel, new PinDialogRequestHandler());
};

/**
 * @implements {GSC.RequestHandler}
 * @constructor
 */
function PinDialogRequestHandler() {}

/**
 * @param {!Object} payload
 * @return {!goog.Promise}
 */
PinDialogRequestHandler.prototype.handleRequest = function(payload) {
  var pinPromise = GSC.ModalDialog.Server.runDialog(
      PIN_DIALOG_URL, PIN_DIALOG_WINDOW_OPTIONS_OVERRIDES);

  var promiseResolver = goog.Promise.withResolver();

  pinPromise.then(function(pin) {
    promiseResolver.resolve(createResponseMessagePayload(pin));
  }, function(error) {
    promiseResolver.reject(error);
  });

  return promiseResolver.promise;
};

function createResponseMessagePayload(pin) {
  return goog.object.create(PIN_MESSAGE_KEY, pin);
}

});  // goog.scope
