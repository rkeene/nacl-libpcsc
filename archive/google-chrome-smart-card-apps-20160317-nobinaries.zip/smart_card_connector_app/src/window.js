// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview Main script of the Smart Card Connector App window.
 */

goog.provide('GoogleSmartCard.ConnectorApp.WindowMain');

goog.require('GoogleSmartCard.Clipboard');
goog.require('GoogleSmartCard.DebugDump');
goog.require('GoogleSmartCard.Logging');
goog.require('GoogleSmartCard.PanelWindow.Client');
goog.require('goog.array');
goog.require('goog.dom');
goog.require('goog.events');
goog.require('goog.log.Logger');

goog.scope(function() {

/** @const */
var USB_DEVICE_FILTERS = [{'interfaceClass': 0x0B}];

/** @const */
var GSC = GoogleSmartCard;

/**
 * @type {!goog.log.Logger}
 * @const
 */
var logger = GSC.Logging.getScopedLogger('ConnectorApp.MainWindow');

logger.fine('The window script has started...');

function loadDeviceList() {
  logger.fine('Requesting available USB devices list...');
  chrome.usb.getDevices({'filters': USB_DEVICE_FILTERS}, getDevicesCallback);
}

/**
 * @param {!chrome.usb.Device} device
 */
function usbDeviceAddedListener(device) {
  logger.fine('A USB device was added: ' + makeReaderDescriptionString(device));
  loadDeviceList();
}

/**
 * @param {!chrome.usb.Device} device
 */
function usbDeviceRemovedListener(device) {
  logger.fine(
      'A USB device was removed: ' + makeReaderDescriptionString(device));
  loadDeviceList();
}

function addDeviceClickListener() {
  logger.fine('Running USB devices selection dialog...');
  chrome.usb.getUserSelectedDevices(
      {'multiple': true, 'filters': USB_DEVICE_FILTERS},
      getUserSelectedDevicesCallback);
}

/**
 * @param {!Array.<!chrome.usb.Device>} devices
 */
function getDevicesCallback(devices) {
  goog.array.sortByKey(devices, function(device) { return device.device; });

  logger.info(devices.length + ' USB device(s) available: ' +
              GSC.DebugDump.dump(devices));
  displayReaders(devices);
}

/**
 * @param {!Array.<!chrome.usb.Device>} readers
 */
function displayReaders(readers) {
  var readersListNode = goog.dom.getElement('readers-list');
  goog.dom.removeChildren(readersListNode);
  goog.array.forEach(readers, function(reader) {
    GSC.Logging.checkWithLogger(logger, !goog.isNull(readersListNode));
    goog.asserts.assert(readersListNode);
    goog.dom.append(
        readersListNode,
        goog.dom.createDom(
            'li', undefined, makeReaderDescriptionString(reader)));
  });
}

/**
 * @param {!chrome.usb.Device} reader
 * @return {string}
 */
function makeReaderDescriptionString(reader) {
  var parts = [];
  if (reader.productName) {
    parts.push(chrome.i18n.getMessage(
        'readerDescriptionProductNamePart', reader.productName));
  }
  if (reader.manufacturerName) {
    parts.push(chrome.i18n.getMessage(
        'readerDescriptionManufacturerNamePart', reader.manufacturerName));
  }
  if (!parts.length)
    return chrome.i18n.getMessage('unknownReaderDescription');
  return parts.join(' ');
}

/**
 * @param {!Array.<!chrome.usb.Device>} devices
 */
function getUserSelectedDevicesCallback(devices) {
  logger.fine('USB selection dialog finished, ' + devices.length + ' devices ' +
              'were chosen');
  loadDeviceList();
}

function exportLogsClickListener() {
  var logBufferState = GSC.Logging.getLogBuffer().getState();
  var dumpedLogs = logBufferState.dumpToText();
  logger.fine(
      'Prepared a (possibly truncated) dump of ' + logBufferState.logCount +
      ' log messages from the log buffer');
  GSC.Clipboard.copyToClipboard(dumpedLogs);
}

loadDeviceList();
chrome.usb.onDeviceAdded.addListener(usbDeviceAddedListener);
chrome.usb.onDeviceRemoved.addListener(usbDeviceRemovedListener);

goog.events.listen(
    goog.dom.getElement('add-device'), 'click', addDeviceClickListener);
goog.events.listen(
    goog.dom.getElement('export-logs'), 'click', exportLogsClickListener);

GSC.PanelWindow.Client.prepareAndShowPanelWindow();

});  // goog.scope
