// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <memory>
#include <string>
#include <thread>

#include <ppapi/c/ppb_instance.h>
#include <ppapi/cpp/core.h>
#include <ppapi/cpp/instance.h>
#include <ppapi/cpp/module.h>
#include <ppapi/cpp/var.h>

#include <google_smart_card_common/logging/logging.h>
#include <google_smart_card_common/messaging/typed_message.h>
#include <google_smart_card_common/messaging/typed_message_router.h>
#include <google_smart_card_common/nacl_io_utils.h>
#include <google_smart_card_common/pp_var_utils/debug_dump.h>
#include <google_smart_card_libusb/global.h>
#include <google_smart_card_pcsc_lite_server/global.h>
#include <google_smart_card_pcsc_lite_server_clients_management/backend.h>
#include <google_smart_card_pcsc_lite_server_clients_management/ready_message.h>

namespace google_smart_card {

namespace {

class PpInstance final : public pp::Instance {
 public:
  explicit PpInstance(PP_Instance instance)
      : pp::Instance(instance),
        libusb_over_chrome_usb_global_(new LibusbOverChromeUsbGlobal(
            &typed_message_router_, this, pp::Module::Get()->core())) {
    StartServicesInitialization();
  }

  ~PpInstance() {
    // Detach the LibusbNaclGlobal and leak it intentionally, so that any
    // concurrent libusb_* function calls still don't result in UB.
    libusb_over_chrome_usb_global_->Detach();
    libusb_over_chrome_usb_global_.release();
  }

  void HandleMessage(const pp::Var& message) override {
    if (!typed_message_router_.OnMessageReceived(message)) {
      GOOGLE_SMART_CARD_LOG_FATAL << "Unexpected message received: " <<
          DebugDumpVar(message);
    }
  }

 private:
  void StartServicesInitialization() {
    std::thread(&PpInstance::InitializeServices, this).detach();
  }

  void InitializeServices() {
    GOOGLE_SMART_CARD_LOG_DEBUG << "Performing services initialization...";

    InitializeNaclIo(*this);
    InitializeAndRunPcscLiteServer();

    pcsc_lite_server_clients_management_backend_.reset(
        new PcscLiteServerClientsManagementBackend(
            this, &typed_message_router_));

    GOOGLE_SMART_CARD_LOG_DEBUG << "All services are successfully " <<
        "initialized, posting ready message...";
    PostMessage(MakeTypedMessage(
        GetPcscLiteServerReadyMessageType(),
        MakePcscLiteServerReadyMessageData()));
  }

  TypedMessageRouter typed_message_router_;
  std::unique_ptr<LibusbOverChromeUsbGlobal> libusb_over_chrome_usb_global_;
  std::unique_ptr<PcscLiteServerClientsManagementBackend>
  pcsc_lite_server_clients_management_backend_;
};

class PpModule final : public pp::Module {
 public:
  pp::Instance* CreateInstance(PP_Instance instance) override {
    return new PpInstance(instance);
  }
};

}  // namespace

}  // namespace google_smart_card

namespace pp {

Module* CreateModule() {
  return new google_smart_card::PpModule();
}

}  // namespace pp
