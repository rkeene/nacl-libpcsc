#!/usr/bin/env bash

# Copyright 2015 The Chromium Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

#
# Race-free version of "mkdir" utility.
#
# Arguments:
#    $1: Path to the resulting directory to be created.
#    $2: (optional) If non-empty, then creates the parent directories too.
#

set -eu

create_dir() {
  mkdir ${1} 2> /dev/null || true
  if [ ! -d ${1} ]; then
    echo "race_free_mkdir.sh failed: couldn't create \"${1}\"" && exit 1
  fi
}

create_dir_recursively() {
  if [[ ( ${1} != "" ) && ( ${1} != "/" ) && ( ${1} != "." ) ]]; then
    create_dir_recursively $(dirname ${1})
    create_dir ${1}
  fi
}

if [ ${2-} ]; then
  create_dir_recursively ${1}
else
  create_dir ${1}
fi
