#!/usr/bin/env bash

# Copyright 2015 The Chromium Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

#
# Race-free version of "cp" utility.
#
# Arguments:
#    $1: Path to the source file.
#    $2: Path to the destination file.
#    $3: (optional) If specified and non-empty, then creates the parent
#        directories too.
#

set -eu

SCRIPTPATH=$(dirname $(realpath ${0}))

DIRPATH=$(dirname ${2})
if [[ ${3-} ]]; then
  ${SCRIPTPATH}/race_free_mkdir.sh ${DIRPATH} ${3}
fi

RANDOM_FILE="$(mktemp -t google_smart_card.XXXXXX)"

cp -p ${1} ${RANDOM_FILE}

if ! mv -f ${RANDOM_FILE} ${2} 2> /dev/null ; then
  if [ ! -f ${2} ]; then
    echo "race_free_cp.sh failed: couldn't create the destination file (\"${2}\")" && exit 1
  fi
  if ! cmp --silent ${1} ${2} > /dev/null 2> /dev/null ; then
    echo "race_free_cp.sh failed: the destination file (\"${2}\") contents are different from the source file (\"${1}\") contents" && exit 1
  fi
fi
