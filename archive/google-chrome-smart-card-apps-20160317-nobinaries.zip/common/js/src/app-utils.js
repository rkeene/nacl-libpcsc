// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.AppUtils');

goog.require('goog.functions');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * Adds a listener for the special Chrome Extensions API event, that makes the
 * whole App being auto-loading (or, more precisely, loading when the Chrome
 * user profile having this App installed is started).
 */
GSC.AppUtils.enableSelfAutoLoading = function() {
  chrome.runtime.onStartup.addListener(goog.functions.NULL);
};

});  // goog.scope
