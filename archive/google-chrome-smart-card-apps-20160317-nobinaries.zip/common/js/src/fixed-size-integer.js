// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.FixedSizeInteger');

goog.require('goog.math.Integer');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * Casts the passed value to the signed 32-bit integer.
 * @param {number} value
 * @return {number}
 */
GSC.FixedSizeInteger.castToInt32 = function(value) {
  return goog.math.Integer.fromNumber(value).toInt();
};

});  // goog.scope
