// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview Server side of the helper library for running the panel
 * windows.
 *
 * Provides methods that can be used for running a panel window.
 *
 * A panel window in Chrome OS is a special type of window that is displayed
 * near the system tray. This is an undocumented feature of the Chrome App API:
 * the value "panel" of field "type" is missing from the API documentation:
 * <https://developer.chrome.com/apps/app_window#type-FrameOptions>.
 */

goog.provide('GoogleSmartCard.PanelWindow.Server');

goog.require('GoogleSmartCard.DebugDump');
goog.require('GoogleSmartCard.Logging');
goog.require('goog.log.Logger');
goog.require('goog.object');

goog.scope(function() {

/** @const */
var DEFAULT_DIALOG_CREATE_WINDOW_OPTIONS = {
  'frame': 'none',
  'hidden': true,
  'resizable': false,
  'type': 'panel'
};

/** @const */
var GSC = GoogleSmartCard;

/**
 * @type {!goog.log.Logger}
 * @const
 */
var logger = GSC.Logging.getScopedLogger('PanelWindow.Server');

/**
 * Creates a new panel window.
 * @param {string} url
 * @param {!chrome.app.window.CreateWindowOptions=}
 * opt_createWindowOptionsOverrides Overrides to the default window options.
 * @param {!Object=} opt_data Optional data to be passed to the created dialog.
 * @param {!Object=} opt_staticData Optional static data to be passed to the
 * created dialog. The difference with opt_data argument is that this data is
 * allowed when 'id' window option is used.
 */
GSC.PanelWindow.Server.createWindow = function(
    url, opt_createWindowOptionsOverrides, opt_data, opt_staticData) {
  var createWindowOptions = goog.object.clone(
      DEFAULT_DIALOG_CREATE_WINDOW_OPTIONS);
  if (opt_createWindowOptionsOverrides) {
    GSC.Logging.checkWithLogger(
        logger,
        !goog.object.containsKey(opt_createWindowOptionsOverrides, 'id') ||
        !opt_data,
        'Passing non-static data to a panel window is allowed only when ' +
        '"id" window option is not specified (as the latter may result in ' +
        'reusing of the existing window, without passing the new data to it)');
    goog.object.extend(createWindowOptions, opt_createWindowOptionsOverrides);
  }

  var panelWindowData = {};
  if (opt_data)
    goog.object.extend(panelWindowData, opt_data);
  if (opt_staticData)
    goog.object.extend(panelWindowData, opt_staticData);

  var createdWindowExtends = {};
  createdWindowExtends[GSC.Logging.GLOBAL_LOG_BUFFER_VARIABLE_NAME] =
      GSC.Logging.getLogBuffer();
  createdWindowExtends['panelWindowData'] = panelWindowData;

  logger.fine(
      'Creating an App window with url="' + url + '", options=' +
      GSC.DebugDump.debugDump(createWindowOptions) + ', data=' +
      GSC.DebugDump.debugDump(panelWindowData));

  chrome.app.window.create(
      url,
      createWindowOptions,
      createWindowCallback.bind(undefined, createdWindowExtends));
};

/**
 * @param {!Object} createdWindowExtends
 * @param {!chrome.app.window.AppWindow} createdWindow
 */
function createWindowCallback(createdWindowExtends, createdWindow) {
  /** @const */
  var CALLBACK_EXECUTED_MARKER = 'isPanelWindowCallbackExecuted';

  var panelWindow = createdWindow.contentWindow;

  if (goog.object.containsKey(panelWindow, CALLBACK_EXECUTED_MARKER)) {
    logger.fine(
        'The panel window callback is executed for the second time, ' +
        'restoring and focusing the window');
    createdWindow.restore();
    createdWindow.focus();
    return;
  }
  panelWindow[CALLBACK_EXECUTED_MARKER] = true;

  logger.fine(
      'The App window callback is executed, injecting the following data ' +
      'into the created window: ' +
      GSC.DebugDump.debugDump(createdWindowExtends));

  goog.object.extend(panelWindow, createdWindowExtends);
}

});  // goog.scope
