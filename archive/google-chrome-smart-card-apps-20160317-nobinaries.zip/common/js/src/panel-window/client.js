// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview Client side of the helper library for implementing the panel
 * windows.
 *
 * Provides methods that are expected to be used inside the panel window script.
 *
 * For the general information on the panel window, refer to the server.js file.
 */

goog.provide('GoogleSmartCard.PanelWindow.Client');

goog.require('GoogleSmartCard.Logging');
goog.require('goog.dom');
goog.require('goog.events');
goog.require('goog.events.EventType');
goog.require('goog.log.Logger');
goog.require('goog.object');
goog.require('goog.string');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * @type {!goog.log.Logger}
 * @const
 */
var logger = GSC.Logging.getScopedLogger('PanelWindow.Client');

/**
 * Returns the additional data that was specified during the dialog creation.
 * @return {Object}
 */
GSC.PanelWindow.Client.getData = function() {
  return goog.object.get(window, 'modalDialogData', {});
};

/**
 * Shows the (initially hidden) panel window, additionally performing the
 * following steps:
 * - Sets the window title explicitly, extracting it from the CSS rules (which
 *   workarounds the issue with Chrome not considering the title::after
 *   pseudo-element as the source for the window title) - FIXME(emaxx):
 *   Investigate why pseudo-elements styling of the title element does not work
 *   with app windows.
 */
GSC.PanelWindow.Client.prepareAndShowPanelWindow = function() {
  setExplicitWindowTitle();
  showWindow();
};

function setExplicitWindowTitle() {
  var element = goog.dom.getElement('title');
  if (!element) {
    logger.fine('Title element was not found, skipped adjusting window title');
    return;
  }
  var style = window.getComputedStyle(element, '::after');
  var contentFromStyle = style.getPropertyValue('content');
  if (!contentFromStyle) {
    logger.fine('Title element style has no content specified, skipped ' +
                'adjusting window title');
    return;
  }
  contentFromStyle = goog.string.stripQuotes(contentFromStyle, '"\'');
  goog.dom.setTextContent(element, contentFromStyle);
  element.removeAttribute('id');
  logger.fine('Title element was adjusted to have the explicit value "' +
              contentFromStyle + '"');
}

function showWindow() {
  logger.fine('Showing the window...');
  chrome.app.window.current().show();
}

});  // goog.scope
