// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.NaclModuleMessageChannel');

goog.require('GoogleSmartCard.DebugDump');
goog.require('GoogleSmartCard.Logging');
goog.require('GoogleSmartCard.TypedMessage');
goog.require('goog.asserts');
goog.require('goog.log.Logger');
goog.require('goog.messaging.AbstractChannel');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * FIXME(emaxx): ???
 * @param {!Element} naclModuleElement
 * @param {!goog.log.Logger} parentLogger
 * @constructor
 * @extends goog.messaging.AbstractChannel
 */
GSC.NaclModuleMessageChannel = function(naclModuleElement, parentLogger) {
  NaclModuleMessageChannel.base(this, 'constructor');

  /** @private */
  this.logger_ = parentLogger;

  /**
   * @type {Element}
   * @private
   */
  this.naclModuleElement_ = naclModuleElement;

  /** @private */
  this.boundMessageEventListener_ = this.messageEventListener_.bind(this);

  this.naclModuleElement_.addEventListener(
      'message', this.boundMessageEventListener_, true);

  this.registerDefaultService(this.defaultServiceCallback_.bind(this));

  this.logger_.fine('Initialized');
};

/** @const */
var NaclModuleMessageChannel = GSC.NaclModuleMessageChannel;

goog.inherits(NaclModuleMessageChannel, goog.messaging.AbstractChannel);

/** @override */
NaclModuleMessageChannel.prototype.send = function(serviceName, payload) {
  GSC.Logging.checkWithLogger(this.logger_, goog.isObject(payload));
  goog.asserts.assertObject(payload);
  var typedMessage = new GSC.TypedMessage(serviceName, payload);
  var message = typedMessage.makeMessage();
  if (this.isDisposed())
    return;
  this.logger_.finest(
      'Sending message to NaCl module: ' + GSC.DebugDump.debugDump(message));
  this.naclModuleElement_.postMessage(message);
};

/** @override */
NaclModuleMessageChannel.prototype.disposeInternal = function() {
  this.naclModuleElement_.removeEventListener(
      'message', this.boundMessageEventListener_, true);
  this.boundMessageEventListener_ = null;

  this.naclModuleElement_ = null;

  NaclModuleMessageChannel.base(this, 'disposeInternal');
};

/** @private */
NaclModuleMessageChannel.prototype.messageEventListener_ = function(message) {
  var messageData = message['data'];

  var typedMessage = GSC.TypedMessage.parseTypedMessage(messageData);
  if (!typedMessage) {
    GSC.Logging.failWithLogger(
        this.logger_,
        'Failed to parse message received from NaCl module: ' +
        GSC.DebugDump.debugDump(messageData));
  }

  this.logger_.finest('Received a message from NaCl module: ' +
                      GSC.DebugDump.debugDump(messageData));
  this.deliver(typedMessage.type, typedMessage.data);
};

/** @private */
NaclModuleMessageChannel.prototype.defaultServiceCallback_ = function(
    serviceName, payload) {
  GSC.Logging.failWithLogger(
      this.logger_,
      'Unhandled message received from NaCl module: serviceName="' +
      serviceName + '", payload=' + GSC.DebugDump.debugDump(payload));
};

});  // goog.scope
