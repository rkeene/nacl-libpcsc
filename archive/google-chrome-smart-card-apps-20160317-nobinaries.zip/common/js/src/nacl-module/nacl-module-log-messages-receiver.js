// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.NaclModuleLogMessagesReceiver');

goog.require('GoogleSmartCard.Logging');
goog.require('goog.messaging.AbstractChannel');
goog.require('goog.asserts');
goog.require('goog.log');
goog.require('goog.log.Level');
goog.require('goog.log.Logger');
goog.require('goog.object');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/** @const */
var SERVICE_NAME = 'log_message';

/** @const */
var LOGGER_TITLE = 'NaCl';

/** @const */
var LOG_LEVEL_MESSAGE_KEY = 'log_level';
/** @const */
var TEXT_MESSAGE_KEY = 'text';

/**
 * @param {!goog.messaging.AbstractChannel} messageChannel
 * @param {!goog.log.Logger} parentLogger
 * @constructor
 */
GSC.NaclModuleLogMessagesReceiver = function(messageChannel, parentLogger) {
  messageChannel.registerService(
      SERVICE_NAME, this.onMessageReceived_.bind(this), true);

  /**
   * @type {!goog.log.Logger}
   * @const
   */
  this.logger = GSC.Logging.getChildLogger(parentLogger, LOGGER_TITLE);
};

/** @const */
var NaclModuleLogMessagesReceiver = GSC.NaclModuleLogMessagesReceiver;

/**
 * @param {string|!Object} messageData
 * @private
 */
NaclModuleLogMessagesReceiver.prototype.onMessageReceived_ = function(
    messageData) {
  GSC.Logging.checkWithLogger(this.logger, goog.isObject(messageData));
  goog.asserts.assertObject(messageData);

  this.logger.log(
      this.extractLogMessageLevel_(messageData),
      this.extractLogMessageText_(messageData));
};

/**
 * @param {!Object} messageData
 * @return {!goog.log.Level}
 * @private
 */
NaclModuleLogMessagesReceiver.prototype.extractLogMessageLevel_ = function(
    messageData) {
  GSC.Logging.checkWithLogger(
      this.logger, goog.object.containsKey(messageData, LOG_LEVEL_MESSAGE_KEY));
  var value = messageData[LOG_LEVEL_MESSAGE_KEY];

  GSC.Logging.checkWithLogger(this.logger, goog.isString(value));
  goog.asserts.assertString(value);

  var result = goog.log.Level.getPredefinedLevel(value);
  GSC.Logging.checkWithLogger(
      this.logger,
      result,
      'Unknown log level specified in the received message: "' + value + '"');
  goog.asserts.assert(result);

  return result;
}

/**
 * @param {!Object} messageData
 * @return {string}
 * @private
 */
NaclModuleLogMessagesReceiver.prototype.extractLogMessageText_ = function(
    messageData) {
  GSC.Logging.checkWithLogger(
      this.logger, goog.object.containsKey(messageData, TEXT_MESSAGE_KEY));
  var value = messageData[TEXT_MESSAGE_KEY];

  GSC.Logging.checkWithLogger(this.logger, goog.isString(value));
  goog.asserts.assertString(value);

  return value;
}

});  // goog.scope
