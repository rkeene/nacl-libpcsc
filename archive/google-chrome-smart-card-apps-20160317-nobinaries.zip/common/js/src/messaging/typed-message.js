// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.TypedMessage');

goog.require('goog.object');

goog.scope(function() {

/** @const */
var TYPE_MESSAGE_KEY = 'type';
/** @const */
var DATA_MESSAGE_KEY = 'data';

/** @const */
var GSC = GoogleSmartCard;

/**
 * @param {string} type
 * @param {!Object} data
 * @constructor
 */
GSC.TypedMessage = function(type, data) {
  /** @type {string} */
  this.type = type;
  /** @type {!Object} */
  this.data = data;
};

/** @const */
var TypedMessage = GSC.TypedMessage;

/**
 * @param {!Object} message
 * @return {TypedMessage}
 */
TypedMessage.parseTypedMessage = function(message) {
  if (goog.object.getCount(message) != 2 ||
      !goog.object.containsKey(message, TYPE_MESSAGE_KEY) ||
      !goog.isString(message[TYPE_MESSAGE_KEY]) ||
      !goog.object.containsKey(message, DATA_MESSAGE_KEY) ||
      !goog.isObject(message[DATA_MESSAGE_KEY])) {
    return null;
  }
  return new TypedMessage(message[TYPE_MESSAGE_KEY], message[DATA_MESSAGE_KEY]);
};

/**
 * @return {!Object}
 */
TypedMessage.prototype.makeMessage = function() {
  return goog.object.create(
      TYPE_MESSAGE_KEY, this.type, DATA_MESSAGE_KEY, this.data);
};

});  // goog.scope
