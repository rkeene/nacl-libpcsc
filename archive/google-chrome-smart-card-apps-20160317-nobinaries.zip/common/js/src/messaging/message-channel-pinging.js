// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.MessageChannelPinging');
goog.provide('GoogleSmartCard.MessageChannelPinging.Pinger');
goog.provide('GoogleSmartCard.MessageChannelPinging.PingResponder');

goog.require('GoogleSmartCard.Logging');
goog.require('GoogleSmartCard.Random');
goog.require('goog.Disposable');
goog.require('goog.Timer');
goog.require('goog.asserts');
goog.require('goog.async.nextTick');
goog.require('goog.log');
goog.require('goog.log.Logger');
goog.require('goog.messaging.AbstractChannel');

goog.scope(function() {

/** @const */
var PINGER_TIMEOUT_MILLISECONDS = goog.DEBUG ? 20 * 1000 : 600 * 1000;
/** @const */
var PINGER_INTERVAL_MILLISECONDS = goog.DEBUG ? 1 * 1000 : 10 * 1000;
/** @const */
var PING_SERVICE_NAME = 'ping';
/** @const */
var PONG_SERVICE_NAME = 'pong';
/** @const */
var PINGER_LOGGER_TITLE = 'Pinger';
/** @const */
var PING_RESPONDER_LOGGER_TITLE = 'PingResponder';
/** @const */
var CHANNEL_ID_MESSAGE_KEY = 'channel_id';

/** @const */
var GSC = GoogleSmartCard;

/**
 * @param {!goog.messaging.AbstractChannel} messageChannel
 * @param {!goog.log.Logger} parentLogger
 * @param {function()=} opt_onEstablished
 * @constructor
 * @extends goog.Disposable
 */
GSC.MessageChannelPinging.Pinger = function(
    messageChannel, parentLogger, opt_onEstablished) {
  Pinger.base(this, 'constructor');

  /**
   * @type {!goog.log.Logger}
   * @const
   */
  this.logger = GSC.Logging.getChildLogger(parentLogger, PINGER_LOGGER_TITLE);

  /** @private */
  this.messageChannel_ = messageChannel;
  this.messageChannel_.registerService(
      PONG_SERVICE_NAME, this.serviceCallback_.bind(this), true);

  /** @private */
  this.onEstablished_ = goog.isDef(opt_onEstablished) ?
      opt_onEstablished : null;

  /**
   * @type {number|null}
   * @private
   */
  this.previousRemoteEndChannelId_ = null;

  /** @private */
  this.timeoutTimerId_ = null;
  this.scheduleTimeoutTimer_();

  goog.async.nextTick(this.postPingMessage_, this);
};

/** @const */
var Pinger = GSC.MessageChannelPinging.Pinger;

goog.inherits(Pinger, goog.Disposable);

/** @override */
Pinger.prototype.disposeInternal = function() {
  this.clearTimeoutTimer_();

  this.onEstablished_ = null;

  this.messageChannel_ = null;

  Pinger.base(this, 'disposeInternal');
};

/**
 * @param {string|!Object} messageData
 * @private
 */
Pinger.prototype.serviceCallback_ = function(messageData) {
  GSC.Logging.checkWithLogger(this.logger, goog.isObject(messageData));
  goog.asserts.assertObject(messageData);

  if (this.isDisposed())
    return;

  if (!goog.object.containsKey(messageData, CHANNEL_ID_MESSAGE_KEY)) {
    this.logger.warning(
        'Received pong message has wrong format: no "' +
        CHANNEL_ID_MESSAGE_KEY + '" field is present. Disposing...');
    this.dispose();
    return;
  }
  var channelId = messageData[CHANNEL_ID_MESSAGE_KEY];
  if (!goog.isNumber(channelId)) {
    this.logger.warning('Received pong message has wrong format: channel id ' +
                        'is not a number. Disposing...');
    this.dispose();
    return;
  }

  if (goog.isNull(this.previousRemoteEndChannelId_)) {
    this.logger.fine(
        'Received the first pong response (remote channel id is ' + channelId +
        '). The message channel is considered established');
    this.previousRemoteEndChannelId_ = channelId;
    if (this.onEstablished_) {
      this.onEstablished_();
      this.onEstablished_ = null;
    }
  } else if (this.previousRemoteEndChannelId_ == channelId) {
    this.logger.finest('Received a pong response with the correct channel ' +
                       'id, so the remote end considered alive');
    this.clearTimeoutTimer_();
    this.scheduleTimeoutTimer_();
  } else {
    this.logger.warning(
        'Received a pong response with a channel id different from the ' +
        'expected one (expected ' + this.previousRemoteEndChannelId_ +
        ', received ' + channelId + '). Disposing...');
    this.dispose();
  }
};

/** @private */
Pinger.prototype.postPingMessage_ = function() {
  if (this.isDisposed())
    return;
  this.logger.finest('Sending a ping request...');

  this.messageChannel_.send(PING_SERVICE_NAME, {});

  goog.Timer.callOnce(
      this.postPingMessage_, PINGER_INTERVAL_MILLISECONDS, this);
};

/** @private */
Pinger.prototype.scheduleTimeoutTimer_ = function() {
  GSC.Logging.checkWithLogger(this.logger, goog.isNull(this.timeoutTimerId_));
  this.timeoutTimerId_ = goog.Timer.callOnce(
      this.timeoutCallback_, PINGER_TIMEOUT_MILLISECONDS, this);
};

/** @private */
Pinger.prototype.clearTimeoutTimer_ = function() {
  if (!goog.isNull(this.timeoutTimerId_)) {
    goog.Timer.clear(this.timeoutTimerId_);
    this.timeoutTimerId_ = null;
  }
};

/** @private */
Pinger.prototype.timeoutCallback_ = function() {
  if (this.isDisposed())
    return;
  this.logger.warning('No pong response received in time, the remote end is ' +
                      'dead. Disposing the messaging channel...');
  this.dispose();
  this.messageChannel_.dispose();
};

/**
 * @param {!goog.messaging.AbstractChannel} messageChannel
 * @param {!goog.log.Logger} parentLogger
 * @constructor
 */
GSC.MessageChannelPinging.PingResponder = function(
    messageChannel, parentLogger) {
  /**
   * @type {!goog.log.Logger}
   * @const
   */
  this.logger = GSC.Logging.getChildLogger(
      parentLogger, PING_RESPONDER_LOGGER_TITLE);

  /** @private */
  this.messageChannel_ = messageChannel;
  this.messageChannel_.registerService(
      PING_SERVICE_NAME, this.serviceCallback_.bind(this), true);

  this.channelId_ = PingResponder.generateChannelId();

  this.logger.fine(
      'Initialized (generated channel id is ' + this.channelId_ + ')');
};

/** @const */
var PingResponder = GSC.MessageChannelPinging.PingResponder;

/**
 * @return {number}
 */
PingResponder.generateChannelId = function() {
  return GSC.Random.randomIntegerNumber();
};

/** @private */
PingResponder.prototype.serviceCallback_ = function() {
  this.logger.finest('Received a ping request, sending pong response...');
  this.messageChannel_.send(PONG_SERVICE_NAME, goog.object.create(
      CHANNEL_ID_MESSAGE_KEY, this.channelId_));
};

});  // goog.scope
