// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.RemoteCallMessage');

goog.require('GoogleSmartCard.DebugDump');
goog.require('goog.iter');
goog.require('goog.object');
goog.require('goog.string');

goog.scope(function() {

/** @const */
var FUNCTION_NAME_MESSAGE_KEY = 'function_name';
/** @const */
var ARGUMENTS_MESSAGE_KEY = 'arguments';

/** @const */
var GSC = GoogleSmartCard;

/**
 * @param {string} functionName
 * @param {!Array.<*>} functionArguments
 * @constructor
 */
GSC.RemoteCallMessage = function(functionName, functionArguments) {
  /** @type {string} */
  this.functionName = functionName;
  /** @type {!Array.<*>} */
  this.functionArguments = functionArguments;
};

/** @const */
var RemoteCallMessage = GSC.RemoteCallMessage;

/**
 * @param {!Object} requestPayload
 * @return {RemoteCallMessage}
 */
RemoteCallMessage.parseRequestPayload = function(requestPayload) {
  if (goog.object.getCount(requestPayload) != 2 ||
      !goog.object.containsKey(requestPayload, FUNCTION_NAME_MESSAGE_KEY) ||
      !goog.isString(requestPayload[FUNCTION_NAME_MESSAGE_KEY]) ||
      !goog.object.containsKey(requestPayload, ARGUMENTS_MESSAGE_KEY) ||
      !goog.isArray(requestPayload[ARGUMENTS_MESSAGE_KEY])) {
    return null;
  }
  return new RemoteCallMessage(
      requestPayload[FUNCTION_NAME_MESSAGE_KEY],
      requestPayload[ARGUMENTS_MESSAGE_KEY]);
};

/**
 * @return {!Object}
 */
RemoteCallMessage.prototype.makeRequestPayload = function() {
  return goog.object.create(
      FUNCTION_NAME_MESSAGE_KEY,
      this.functionName,
      ARGUMENTS_MESSAGE_KEY,
      this.functionArguments);
};

/**
 * @return {string}
 */
RemoteCallMessage.prototype.getDebugRepresentation = function() {
  return goog.string.subs(
      '%s(%s)',
      this.functionName,
      goog.iter.join(goog.iter.map(
          this.functionArguments, GSC.DebugDump.debugDump), ', '));
};

});  // goog.scope
