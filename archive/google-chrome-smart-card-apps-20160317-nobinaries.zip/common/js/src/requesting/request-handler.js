// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.RequestHandler');

goog.require('goog.Promise');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * @interface
 */
GSC.RequestHandler = function() {};

/** @const */
var RequestHandler = GSC.RequestHandler;

/**
 * @param {!Object} payload
 * @return {!goog.Promise}
 */
RequestHandler.prototype.handleRequest = function(payload) {};

});  // goog.scope
