// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview FIXME(emaxx).
 */

goog.provide('GoogleSmartCard.Clipboard');

goog.require('GoogleSmartCard.Logging');
goog.require('goog.dom');
goog.require('goog.log.Logger');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * @type {!goog.log.Logger}
 * @const
 */
var logger = GSC.Logging.getLogger('Clipboard');

/**
 * Copies the passed text to the clipboard.
 *
 * The text may contain the \n characters as a delimiter for the multiple lines.
 */
GSC.Clipboard.copyToClipboard = function(text) {
  var element = goog.dom.createDom('textarea', {'textContent': text});
  document.body.appendChild(element);
  element.select();
  var success = document.execCommand('copy');
  document.body.removeChild(element);

  if (success) {
    logger.fine('Copied text of ' + text.length + ' bytes to clipboard');
  } else {
    logger.severe(
        'Failed to copy the text of ' + text.length + ' bytes to clipboard');
  }
};

});  // goog.scope
