// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.Random');

goog.require('goog.array');

goog.scope(function() {

/** @const */
var RANDOM_INTEGER_BYTE_COUNT = 6;

/** @const */
var GSC = GoogleSmartCard;

/**
 * Generates a cryptographically random integer number.
 * @return {number}
 */
GSC.Random.randomIntegerNumber = function() {
  var randomBytes = new Uint8Array(RANDOM_INTEGER_BYTE_COUNT);
  window.crypto.getRandomValues(randomBytes);
  var result = 0;
  goog.array.forEach(randomBytes, function(byteValue) {
    result = result * 256 + byteValue;
  });
  return result;
};

});  // goog.scope
