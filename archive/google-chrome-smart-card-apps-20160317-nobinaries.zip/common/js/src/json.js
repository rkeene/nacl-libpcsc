// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.Json');

goog.require('goog.Promise');
goog.require('goog.json.NativeJsonProcessor');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * Parses a JSON string and returns the result or the error message through the
 * returned promise.
 *
 * This is a replacement of the goog.json.parse method, as it breaks in the
 * Chrome App environment (it tries to use eval, which is not allowed in
 * packaged Chrome Apps).
 * @param {string} jsonString
 * @return {!goog.Promise.<*>}
 */
GSC.Json.parse = function(jsonString) {
  var processor = new goog.json.NativeJsonProcessor();
  /** @preserveTry */
  try {
    return goog.Promise.resolve(processor.parse(jsonString));
  } catch (exc) {
    return goog.Promise.reject(exc);
  }
};

});  // goog.scope
