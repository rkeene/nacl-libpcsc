// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview FIXME(emaxx).
 */

goog.provide('GoogleSmartCard.Logging');

goog.require('GoogleSmartCard.LogBuffer');
goog.require('goog.asserts');
goog.require('goog.debug');
goog.require('goog.debug.Console');
goog.require('goog.log');
goog.require('goog.log.Level');
goog.require('goog.log.LogRecord');
goog.require('goog.log.Logger');
goog.require('goog.string');

goog.scope(function() {

/** @const */
var LOGGER_SCOPE = 'GoogleSmartCard';

/**
 * @type {!goog.log.Level}
 * @const
 */
var ROOT_LOGGER_LEVEL = goog.DEBUG ? goog.log.Level.FINE : goog.log.Level.INFO;

/** @const */
var LOG_BUFFER_CAPACITY = goog.DEBUG ? 10 * 1000 : 1000;

/** @const */
var GSC = GoogleSmartCard;

/**
 * @type {!goog.log.Logger}
 * @const
 */
var rootLogger = goog.asserts.assert(goog.log.getLogger(
    goog.log.ROOT_LOGGER_NAME));

/**
 * @type {!goog.log.Logger}
 * @const
 */
var logger = goog.asserts.assert(goog.log.getLogger(LOGGER_SCOPE));

/** @type {boolean} */
var wasLoggingSetUp = false;

/**
 * FIXME(emaxx)
 * @const
 */
GSC.Logging.GLOBAL_LOG_BUFFER_VARIABLE_NAME = 'googleSmartCardLogBuffer';

/**
 * Sets up logging parameters and log buffering.
 *
 * This function is called automatically when this library file is included.
 */
GSC.Logging.setupLogging = function() {
  if (wasLoggingSetUp)
    return;
  wasLoggingSetUp = true;

  setupConsoleLogging();
  setupRootLoggerLevel();

  logger.fine('Logging was set up with level=' + ROOT_LOGGER_LEVEL.name +
              ' and enabled logging to JS console');

  setupLogBuffer();
};

/**
 * Returns a logger.
 * @param {string} name
 * @param {!goog.log.Level=} opt_level
 * @return {!goog.log.Logger}
 */
GSC.Logging.getLogger = function(name, opt_level) {
  var logger = goog.log.getLogger(name, opt_level);
  GSC.Logging.check(logger);
  goog.asserts.assert(logger);
  return logger;
};

/**
 * Returns a library-scoped logger.
 * @param {string} name
 * @param {!goog.log.Level=} opt_level
 * @return {!goog.log.Logger}
 */
GSC.Logging.getScopedLogger = function(name, opt_level) {
  var fullName = LOGGER_SCOPE;
  if (name)
    fullName += '.' + name;
  return GSC.Logging.getLogger(fullName);
};

/**
 * Returns the logger with the specified name relative to the specified parent
 * logger.
 * @param {!goog.log.Logger} parentLogger
 * @param {string} relativeName
 * @param {!goog.log.Level=} opt_level
 * @return {!goog.log.Logger}
 */
GSC.Logging.getChildLogger = function(
    parentLogger, relativeName, opt_level) {
  return GSC.Logging.getLogger(parentLogger.getName() + '.' + relativeName);
};

/**
 * Checks if the condition evaluates to true.
 *
 * In contrast to goog.asserts.assert method, this method works in non-Debug
 * builds too (provided that the goog.asserts.ENABLE_ASSERTS definition is
 * true).
 * @template T
 * @param {T} condition The condition to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 */
GSC.Logging.check = function(condition, opt_message, var_args) {
  if (!condition)
    GSC.Logging.fail(opt_message, Array.prototype.slice.call(arguments, 2));
};

/**
 * The same as GSC.Logging.check, but the message is prefixed with the logger
 * title.
 * @template T
 * @param {!goog.log.Logger} logger The logger which name is to be prepended
 * to the error message.
 * @param {T} condition The condition to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 */
GSC.Logging.checkWithLogger = function(
    logger, condition, opt_message, var_args) {
  if (!condition)
    GSC.Logging.failWithLogger(logger, opt_message, var_args);
};

/**
 * Fails with the specified message.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 */
GSC.Logging.fail = function(opt_message, var_args) {
  goog.asserts.fail(opt_message, Array.prototype.slice.call(arguments, 1));
};

/**
 * Same as GSC.Logging.fail, but the message is prefixed with the logger title.
 * @param {!goog.log.Logger} logger The logger which name is to be prepended
 * to the error message.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 */
GSC.Logging.failWithLogger = function(logger, opt_message, var_args) {
  var transformedMessage = 'Failure in ' + logger.getName();
  if (goog.isDef(opt_message)) {
    transformedMessage += ': ' + goog.string.subs(
        opt_message, Array.prototype.slice.call(arguments, 2));
  }
  goog.asserts.fail(transformedMessage);
};

/**
 * FIXME(emaxx)
 * @return {!GSC.LogBuffer}
 */
GSC.Logging.getLogBuffer = function() {
  return window[GSC.Logging.GLOBAL_LOG_BUFFER_VARIABLE_NAME];
};

function setupConsoleLogging() {
  var console = new goog.debug.Console;
  console.setCapturing(true);
}

function setupRootLoggerLevel() {
  rootLogger.setLevel(ROOT_LOGGER_LEVEL);
}

function setupLogBuffer() {
  var logBuffer;
  if (goog.object.containsKey(
          window, GSC.Logging.GLOBAL_LOG_BUFFER_VARIABLE_NAME)) {
    logBuffer = window[GSC.Logging.GLOBAL_LOG_BUFFER_VARIABLE_NAME];
    logger.fine('Detected an existing LogBuffer instance, attaching it to ' +
                'the root logger');
  } else {
    var logBufferLoggerPrefix = goog.string.subs(
        '<%s:%s>', chrome.runtime.id, document.location.pathname);
    logBuffer = new GSC.LogBuffer(LOG_BUFFER_CAPACITY, logBufferLoggerPrefix);
    window[GSC.Logging.GLOBAL_LOG_BUFFER_VARIABLE_NAME] = logBuffer;
    logger.fine(
        'Created a new LogBuffer instance, attaching it to the root logger');
  }

  logBuffer.attachToLogger(rootLogger);
}

GSC.Logging.setupLogging();

});  // goog.scope
