// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview FIXME(emaxx).
 */

goog.provide('GoogleSmartCard.LogBuffer');

goog.require('goog.array');
goog.require('goog.debug.TextFormatter');
goog.require('goog.log.LogRecord');
goog.require('goog.log.Logger');
goog.require('goog.structs.CircularBuffer');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * FIXME(emaxx).
 * @param {number} capacity
 * @param {string=} opt_loggerPrefix
 * @constructor
 */
GSC.LogBuffer = function(capacity, opt_loggerPrefix) {
  /** @private */
  this.capacity_ = capacity;
  /** @private */
  this.loggerPrefix_ = opt_loggerPrefix;

  /** @private */
  this.size_ = 0;

  /** @private */
  this.logsPrefixCapacity_ = capacity / 2;
  /** @private */
  this.logsPrefix_ = [];

  /** @private */
  this.logsSuffix_ = new goog.structs.CircularBuffer(
      capacity - this.logsPrefixCapacity_);
};

/** @const */
var LogBuffer = GSC.LogBuffer;

/**
 * @param {!goog.log.Logger} logger
 */
LogBuffer.prototype.attachToLogger = function(logger) {
  logger.addHandler(this.onLogMessage_.bind(this));
};

/**
 * FIXME(emaxx)
 * @param {number} logCount
 * @param {!Array.<!goog.log.LogRecord>} logsPrefix
 * @param {number} skippedLogCount
 * @param {!Array.<!goog.log.LogRecord>} logsSuffix
 * @constructor
 */
LogBuffer.State = function(logCount, logsPrefix, skippedLogCount, logsSuffix) {
  this.logCount = logCount;
  this.logsPrefix = logsPrefix;
  this.skippedLogCount = skippedLogCount;
  this.logsSuffix = logsSuffix;
};

/**
 * FIXME(emaxx)
 * @return {string}
 */
LogBuffer.State.prototype.dumpToText = function() {
  var textFormatter = new goog.debug.TextFormatter;
  var result = '';

  goog.array.forEach(this.logsPrefix, function(logRecord) {
    result += textFormatter.formatRecord(logRecord);
  });

  if (this.skippedLogCount)
    result += '\n... skipped ' + this.skippedLogCount + ' messages ...\n\n';

  goog.array.forEach(this.logsSuffix, function(logRecord) {
    result += textFormatter.formatRecord(logRecord);
  });

  return result;
};

/**
 * FIXME(emaxx)
 * @return {!LogBuffer.State}
 */
LogBuffer.prototype.getState = function() {
  return new LogBuffer.State(
      this.size_,
      goog.array.clone(this.logsPrefix_),
      this.size_ - this.logsPrefix_.length - this.logsSuffix_.getCount(),
      this.logsSuffix_.getValues());
};

/**
 * @param {!goog.log.LogRecord} logRecord
 * @private
 */
LogBuffer.prototype.onLogMessage_ = function(logRecord) {
  this.addLogRecord_(logRecord);
};

/**
 * @param {!goog.log.LogRecord} logRecord
 * @private
 */
LogBuffer.prototype.addLogRecord_ = function(logRecord) {
  var loggerNameParts = [];
  if (this.loggerPrefix_)
    loggerNameParts.push(this.loggerPrefix_);
  if (logRecord.getLoggerName())
    loggerNameParts.push(logRecord.getLoggerName());
  var prefixedLoggerName = loggerNameParts.join('.');
  var prefixedLogRecord = new goog.log.LogRecord(
      logRecord.getLevel(),
      logRecord.getMessage(),
      prefixedLoggerName,
      logRecord.getMillis(),
      logRecord.getSequenceNumber());

  if (this.logsPrefix_.length < this.logsPrefixCapacity_)
    this.logsPrefix_.push(prefixedLogRecord);
  else
    this.logsSuffix_.add(prefixedLogRecord);
  ++this.size_;
};

});  // goog.scope
