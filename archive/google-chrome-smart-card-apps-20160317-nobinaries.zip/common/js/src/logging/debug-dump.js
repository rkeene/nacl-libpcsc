// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.DebugDump');

goog.require('goog.array');
goog.require('goog.functions');
goog.require('goog.iter');
goog.require('goog.json');
goog.require('goog.math');
goog.require('goog.object');
goog.require('goog.string');
goog.require('goog.structs');
goog.require('goog.structs.Map');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * @param {*} value
 * @return {string}
 */
function encodeJson(value) {
  return goog.json.serialize(value) || 'null';
}

/**
 * @param {number} value
 * @return {number}
 */
function guessIntegerBitLength(value) {
  /** @const */
  var BIT_LENGTHS = [8, 32, 64];
  var result = null;
  goog.array.forEach(BIT_LENGTHS, function(bitLength) {
    var signedBegin = -Math.pow(2, bitLength - 1);
    var unsignedEnd = Math.pow(2, bitLength);
    if (signedBegin <= value && value < unsignedEnd && goog.isNull(result))
      result = bitLength;
  });
  return result;
}

/**
 * @param {!Array|!Uint8Array|!goog.structs.Map|!goog.structs.Set} value
 * @return {string}
 */
function dumpSequence(value) {
  var dumpedItems = goog.iter.map(value, GSC.DebugDump.dump);
  return goog.iter.join(dumpedItems, ', ');
}

/**
 * @param {!Object} value
 * @return {string}
 */
function dumpMapping(value) {
  var dumpedItems = goog.array.map(goog.object.getKeys(value), function(key) {
    return key + ': ' + GSC.DebugDump.dump(value[key]);
  });
  return goog.iter.join(dumpedItems, ', ');
}

/**
 * @param {number} value
 * @return {string}
 */
function dumpNumber(value) {
  // Format things like "NaN" and "Infinity" textually
  if (!goog.math.isFiniteNumber(value))
    return value.toString();

  // Format real numbers by the default JSON formatter
  if (!goog.math.isInt(value))
    return encodeJson(value);

  var bitLength = guessIntegerBitLength(value);

  // Format huge integers by the default JSON formatter
  if (!bitLength)
    return encodeJson(value);

  // Format negative integers, which are not too huge, in the unsigned
  // representation (with the guessed bit length)
  if (value < 0)
    value += Math.pow(2, bitLength);

  // Format non-negative integers, which are not too huge, in the hexadecimal
  // system
  var hexValue = value.toString(16).toUpperCase();
  var expectedHexLength = bitLength / 4;
  return '0x' + goog.string.repeat('0', expectedHexLength - hexValue.length) +
         hexValue;
}

/**
 * @param {string} value
 * @return {string}
 */
function dumpString(value) {
  return '"' + value + '"';
}

/**
 * @param {!Array|!Uint8Array} value
 * @return {string}
 */
function dumpArray(value) {
  return '[' + dumpSequence(value) + ']';
}

/**
 * @param {function(...)} value
 * @return {string}
 */
function dumpFunction(value) {
  return '<Function>';
}

/**
 * @param {!ArrayBuffer} value
 * @return {string}
 */
function dumpArrayBuffer(value) {
  return 'ArrayBuffer[' + dumpSequence(new Uint8Array(value)) + ']';
}

/**
 * @param {!goog.structs.Map} value
 * @return {string}
 */
function dumpMap(value) {
  var object = goog.structs.map(value, goog.functions.identity, {});
  return 'Map{' + dumpMapping(object) + '}';
}

/**
 * @param {!goog.structs.Set} value
 * @return {string}
 */
function dumpSet(value) {
  return 'Set{' + dumpSequence(value) + '}';
}

/**
 * @param {!Object} value
 * @return {string}
 */
function dumpObject(value) {
  return '{' + dumpMapping(value) + '}';
}

/**
 * @param {*} value
 * @return {string}
 */
GSC.DebugDump.dump = function(value) {
  if (!goog.isDef(value))
    return 'undefined';
  if (goog.isNull(value))
    return 'null';
  if (goog.isNumber(value))
    return dumpNumber(value);
  if (goog.isString(value))
    return dumpString(value);
  if (goog.isArray(value))
    return dumpArray(value);
  if (goog.isFunction(value))
    return dumpFunction(value);
  if (value instanceof ArrayBuffer)
    return dumpArrayBuffer(value);
  if (value instanceof goog.structs.Map)
    return dumpMap(value);
  if (value instanceof goog.structs.Set)
    return dumpSet(value);
  if (goog.isObject(value))
    return dumpObject(value);
  return encodeJson(value);
};

if (goog.DEBUG) {
  /**
   * @param {*} value
   * @return {string}
   */
  GSC.DebugDump.debugDump = function(value) {
    return GSC.DebugDump.dump(value);
  };
} else {
  GSC.DebugDump.debugDump = function(value) {
    // For privacy reasons, in non-Debug builds no actual data is dumped.
    return '<stripped value>';
  };
}

});  // goog.scope
