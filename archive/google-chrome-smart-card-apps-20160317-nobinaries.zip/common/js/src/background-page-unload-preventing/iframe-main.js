// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview Entry point of the main script in the background page unload
 * preventing iframe.
 *
 * By default, App's background page gets automatically unloaded by Chrome after
 * some period of inactivity (see
 * https://developer.chrome.com/apps/event_pages). In order to suppress such
 * behavior, an iframe with this script can be created from the background
 * page. The script opens a Port that connects to the same App (the other end
 * should be handled in the background page). Keeping the Port opened prevents
 * the background page from being unloaded.
 */

goog.provide('GoogleSmartCard.BackgroundPageUnloadPreventing.IFrameMain');

goog.require('GoogleSmartCard.Logging');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * @type {!goog.log.Logger}
 * @const
 */
var logger = GSC.Logging.getScopedLogger(
    'BackgroundPageUnloadPreventing.IFrame');

logger.fine('Opening a port to the background page...');
/**
 * @type {!Port}
 * @const
 */
var port = chrome.runtime.connect(
    {'name': 'background-page-unload-preventing'});

port.onDisconnect.addListener(function() {
  GSC.Logging.failWithLogger(
      logger, 'The message port to the background page was disconnected');
});

port.onMessage.addListener(function() {
  GSC.Logging.failWithLogger(
      logger,
      'Unexpectedly received a message through the message port from the ' +
      'background page');
});

});  // goog.scope
