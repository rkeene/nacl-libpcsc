// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

goog.provide('GoogleSmartCard.BackgroundPageUnloadPreventing');

goog.require('GoogleSmartCard.Logging');
goog.require('goog.dom');
goog.require('goog.log.Logger');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * @type {!goog.log.Logger}
 * @const
 */
var logger = GSC.Logging.getScopedLogger('BackgroundPageUnloadPreventing');

/** @type {boolean} */
var enabled = false;

/**
 * Enables preventing of the background page from being unloaded.
 *
 * By default, App's background page gets automatically unloaded by Chrome after
 * some period of inactivity (see
 * https://developer.chrome.com/apps/event_pages).
 *
 * This function allows to suppress this behavior by creating an iframe with the
 * script that opens a Port connecting to the same App (the other end
 * is handled here, in the background page). Keeping the Port opened prevents
 * the background page from being unloaded.
 */
GSC.BackgroundPageUnloadPreventing.enable = function() {
  if (enabled) {
    logger.fine('Trying to enable for the second time. Ignoring this attempt');
    return;
  }
  enabled = true;

  chrome.runtime.onConnect.addListener(connectListener);

  chrome.runtime.onSuspend.addListener(suspendListener);

  logger.fine('Enabling: creating an iframe...');
  createIFrameElement();
};

function createIFrameElement() {
  var iframe = goog.dom.createDom('iframe', {
    'src': 'background-page-unload-preventing-iframe.html'
  });
  GSC.Logging.checkWithLogger(logger, document.body);
  document.body.appendChild(iframe);
}

/**
 * @param {!Port} port
 */
function connectListener(port) {
  if (port.name == 'background-page-unload-preventing') {
    logger.fine('Success: received a port opened by the iframe');

    port.onDisconnect.addListener(function() {
      GSC.Logging.failWithLogger(
          logger, 'The message port to the iframe was disconnected');
    });

    port.onMessage.addListener(function() {
      GSC.Logging.failWithLogger(
          logger,
          'Unexpectedly received a message from the message port from the ' +
          'iframe');
    });
  }
}

function suspendListener() {
  GSC.Logging.failWithLogger(logger, 'Suspend event was received');
}

});  // goog.scope
