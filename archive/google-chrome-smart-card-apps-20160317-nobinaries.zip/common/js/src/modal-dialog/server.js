// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview Server side of the helper library for implementing the modal
 * dialogs.
 *
 * Provides methods that can be used for running a modal dialog and receiving
 * its result.
 */

goog.provide('GoogleSmartCard.ModalDialog.Server');

goog.require('GoogleSmartCard.DebugDump');
goog.require('GoogleSmartCard.Logging');
goog.require('goog.Promise');
goog.require('goog.log.Logger');
goog.require('goog.object');
goog.require('goog.promise.Resolver');

goog.scope(function() {

/** @const */
var DEFAULT_DIALOG_CREATE_WINDOW_OPTIONS = {
  'alwaysOnTop': true,
  'frame': 'none',
  'hidden': true,
  'resizable': false,
  'visibleOnAllWorkspaces': true
};

/** @const */
var GSC = GoogleSmartCard;

/**
 * @type {!goog.log.Logger}
 * @const
 */
var logger = GSC.Logging.getScopedLogger('ModalDialog.Server');

/**
 * Creates a new modal dialog and returns a promise of the data it returns.
 * @param {string} url
 * @param {!chrome.app.window.CreateWindowOptions=}
 * opt_createWindowOptionsOverrides Overrides to the default window options.
 * Note that the 'id' option is disallowed.
 * @param {!Object=} opt_data Optional data to be passed to the created dialog.
 * @return {!goog.Promise}
 */
GSC.ModalDialog.Server.runDialog = function(
    url, opt_createWindowOptionsOverrides, opt_data) {
  var createWindowOptions = goog.object.clone(
      DEFAULT_DIALOG_CREATE_WINDOW_OPTIONS);
  if (opt_createWindowOptionsOverrides) {
    GSC.Logging.checkWithLogger(
        logger,
        !goog.object.containsKey(opt_createWindowOptionsOverrides, 'id'),
        '"id" window option is disallowed for the modal dialogs (as this ' +
        'option may result in not creating of the new modal dialog)');
    goog.object.extend(createWindowOptions, opt_createWindowOptionsOverrides);
  }

  var promiseResolver = goog.Promise.withResolver();

  var createdWindowExtends = {};
  if (goog.isDef(opt_data))
    createdWindowExtends['modalDialogData'] = opt_data;
  createdWindowExtends['resolveModalDialog'] = promiseResolver.resolve;
  createdWindowExtends['rejectModalDialog'] = promiseResolver.reject;

  logger.fine(
      'Creating an App window with url="' + url + '", options=' +
      GSC.DebugDump.debugDump(createWindowOptions) + ', data=' +
      GSC.DebugDump.debugDump(createdWindowExtends));

  chrome.app.window.create(
      url,
      createWindowOptions,
      createWindowCallback.bind(undefined, createdWindowExtends));

  return promiseResolver.promise;
};

/**
 * @param {!Object} createdWindowExtends
 * @param {!chrome.app.window.AppWindow} createdWindow
 */
function createWindowCallback(createdWindowExtends, createdWindow) {
  var dialogWindow = createdWindow.contentWindow;

  logger.fine(
      'The App window callback is executed, injecting the following data ' +
      'into the created window: ' +
      GSC.DebugDump.debugDump(createdWindowExtends));

  goog.object.extend(dialogWindow, createdWindowExtends);

  createdWindow.drawAttention();
}

});  // goog.scope
