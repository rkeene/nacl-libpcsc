// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview Client side of the helper library for implementing the modal
 * dialogs.
 *
 * Provides methods that are expected to be used inside the modal dialog script.
 */

goog.provide('GoogleSmartCard.ModalDialog.Client');

goog.require('GoogleSmartCard.Logging');
goog.require('goog.events');
goog.require('goog.events.EventType');
goog.require('goog.events.KeyCodes');
goog.require('goog.log.Logger');
goog.require('goog.object');

goog.scope(function() {

/** @const */
var GSC = GoogleSmartCard;

/**
 * @type {!goog.log.Logger}
 * @const
 */
var logger = GSC.Logging.getScopedLogger('ModalDialog.Client');

/**
 * Returns the additional data that was specified during the dialog creation.
 * @return {Object}
 */
GSC.ModalDialog.Client.getData = function() {
  return goog.object.get(window, 'modalDialogData', {});
};

/**
 * Resolves the modal dialog, passing the specified result to the caller in the
 * parent window (i.e. in the App's background page) and closing the current
 * window.
 * @param {*} result
 */
GSC.ModalDialog.Client.resolveModalDialog = function(result) {
  var callback = window['resolveModalDialog'];
  GSC.Logging.checkWithLogger(logger, callback);
  callback(result);
  closeWindow();
};

/**
 * Rejects the modal dialog, passing the specified error to the caller in the
 * parent window (i.e. in the App's background page) and closing the current
 * window.
 * @param {*} error
 */
GSC.ModalDialog.Client.rejectModalDialog = function(error) {
  var callback = window['rejectModalDialog'];
  GSC.Logging.checkWithLogger(logger, callback);
  callback(error);
  closeWindow();
};

/**
 * Shows the (initially hidden) dialog modal window, additionally performing the
 * following steps:
 * - Resizes the window height so that it fits the entire content without
 *   overflowing (though still conforming to the minimum/maximum bounds when
 *   they are specified for the window).
 * - Adds a listener for unhandled ESC key presses, which closes the window.
 * - Adds listener for the window close event, which rejects the dialog (this
 *   covers the case when the dialog is closed by user by clicking at the
 *   close button).
 */
GSC.ModalDialog.Client.prepareAndShowModalDialog = function() {
  setWindowHeightToFitContent();
  setupClosingOnEscape();
  setupRejectionOnWindowClose();
  showWindow();
};

function closeWindow() {
  chrome.app.window.current().close();
}

function setWindowHeightToFitContent() {
  var wholeContentHeight = document.documentElement.offsetHeight;
  logger.fine('Resizing the window size to ' + wholeContentHeight + 'px');
  chrome.app.window.current().innerBounds.height = wholeContentHeight;
}

function setupClosingOnEscape() {
  goog.events.listen(
      document,
      goog.events.EventType.KEYDOWN,
      documentClosingOnEscapeKeyDownListener);
}

function setupRejectionOnWindowClose() {
  chrome.app.window.current().onClosed.addListener(
      windowCloseDialogRejectionListener);
}

function showWindow() {
  chrome.app.window.current().show();
}

function documentClosingOnEscapeKeyDownListener(event) {
  if (event.keyCode == goog.events.KeyCodes.ESC)
    closeWindow();
}

function windowCloseDialogRejectionListener() {
  GSC.ModalDialog.Client.rejectModalDialog(new Error('Dialog was closed'));
}

});  // goog.scope
