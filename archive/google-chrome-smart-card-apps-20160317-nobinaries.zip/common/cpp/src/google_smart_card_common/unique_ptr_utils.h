// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_UNIQUE_PTR_UTILS_H_
#define GOOGLE_SMART_CARD_COMMON_UNIQUE_PTR_UTILS_H_

#include <memory>
#include <utility>

namespace google_smart_card {

// Replacement of std::make_unique, which will be introducted only in C++14.
template <typename T, typename ... Args>
inline std::unique_ptr<T> MakeUnique(Args&& ... args) {
  return std::unique_ptr<T>(new T(std::forward<Args>(args)...));
}

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_UNIQUE_PTR_UTILS_H_
