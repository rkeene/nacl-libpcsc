// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Helper functions for working with multi-strings.
//
// A multi-string is a sequence of zero-terminated strings with an additional
// zero character appended after the end of the last string.

#ifndef GOOGLE_SMART_CARD_COMMON_MULTI_STRING_H_
#define GOOGLE_SMART_CARD_COMMON_MULTI_STRING_H_

#include <string>
#include <vector>

namespace google_smart_card {

std::string CreateMultiString(const std::vector<std::string>& elements);

std::vector<std::string> ExtractMultiStringElements(
    const std::string& multi_string);

std::vector<std::string> ExtractMultiStringElements(
    const char* multi_string);

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_MULTI_STRING_H_
