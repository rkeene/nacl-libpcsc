// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_NACL_IO_UTILS_H_
#define GOOGLE_SMART_CARD_COMMON_NACL_IO_UTILS_H_

#include <ppapi/cpp/instance.h>

namespace google_smart_card {

// Initializes NaCl nacl_io library and prepares /tmp and /crx directories.
//
// The /tmp directory is mounted to a temporary in-memory file system.
//
// The /crx directory is mounted to the extension package root.
//
// Note: This function must be called not from the main Pepper thread!
void InitializeNaclIo(const pp::Instance& pp_instance);

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_NACL_IO_UTILS_H_
