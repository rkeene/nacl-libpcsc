// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/nacl_io_utils.h>

#include <sys/mount.h>

#include <nacl_io/nacl_io.h>
#include <ppapi/cpp/core.h>
#include <ppapi/cpp/module.h>

#include <google_smart_card_common/logging/logging.h>

namespace google_smart_card {

void InitializeNaclIo(const pp::Instance& pp_instance) {
  GOOGLE_SMART_CARD_LOG_DEBUG << "[nacl_io] Initializing...";

  pp::Module* const pp_module = pp::Module::Get();
  GOOGLE_SMART_CARD_CHECK(pp_module);

  GOOGLE_SMART_CARD_CHECK(!pp_module->core()->IsMainThread());

  GOOGLE_SMART_CARD_CHECK(::nacl_io_init_ppapi(
      pp_instance.pp_instance(), pp_module->get_browser_interface()) == 0);

  GOOGLE_SMART_CARD_CHECK(::umount("/") == 0);

  GOOGLE_SMART_CARD_CHECK(::mount("", "/tmp", "memfs", 0, "") == 0);

  GOOGLE_SMART_CARD_CHECK(::mount(
      "/", "/crx", "httpfs", 0, "manifest=/nacl_io_manifest.txt") == 0);

  GOOGLE_SMART_CARD_LOG_DEBUG << "[nacl_io] successfully initialized";
}

}  // namespace google_smart_card
