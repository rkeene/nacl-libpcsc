// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/formatting.h>

#include <cstdio>
#include <vector>

const size_t kInitialPrintfBufferSize = 100;

namespace google_smart_card {

std::string FormatPrintfTemplate(const char* format, ...) {
  va_list var_args;
  va_start(var_args, format);
  const std::string result = FormatPrintfTemplate(format, var_args);
  va_end(var_args);
  return result;
}

std::string FormatPrintfTemplate(const char* format, va_list var_args) {
  std::vector<char> buffer(kInitialPrintfBufferSize);
  for (;;) {
    va_list var_args_copy;
    va_copy(var_args_copy, var_args);
    const int result = std::vsnprintf(
        &buffer[0], buffer.size(), format, var_args_copy);
    va_end(var_args_copy);
    if (0 <= result && result < static_cast<int>(buffer.size()))
      return std::string(buffer.begin(), buffer.begin() + result);
    const size_t new_size = result > 0 ? result + 1 : buffer.size() * 2;
    buffer.resize(new_size);
  }
}

}  // namespace google_smart_card
