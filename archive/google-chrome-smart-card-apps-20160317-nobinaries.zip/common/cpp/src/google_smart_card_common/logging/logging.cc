// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/logging/logging.h>

#include <iostream>
#include <utility>

#ifdef __native_client__
#include <ppapi/cpp/var.h>
#include <ppapi/cpp/var_dictionary.h>
#include <ppapi/cpp/instance.h>
#include <ppapi/cpp/module.h>
#endif  // __native_client__

const char kTypeMessageKey[] = "type";
const char kMessageType[] = "log_message";
const char kDataMessageKey[] = "data";
const char kDataLogLevelMessageKey[] = "log_level";
const char kDataTextMessageKey[] = "text";

namespace google_smart_card {

namespace {

std::string StringifyLogSeverity(internal::LogSeverity severity) {
  switch (severity) {
    case internal::LogSeverity::kDebug:
      return "DEBUG";
    case internal::LogSeverity::kInfo:
      return "INFO";
    case internal::LogSeverity::kWarning:
      return "WARNING";
    case internal::LogSeverity::kError:
      return "ERROR";
    case internal::LogSeverity::kFatal:
      return "FATAL";
    default:
      // This should be never reached, but it's easier to provide a safe
      // default here.
      return "";
  }
}

void EmitLogMessageToStderr(
    internal::LogSeverity severity, const std::string& message_text) {
  // Prepare the whole message in advance, so that we don't mess with other
  // threads writing to std::cerr too.
  std::ostringstream stream;
  stream << "[NaCl module " << StringifyLogSeverity(severity) << "] " <<
      message_text << std::endl;

  std::cerr << stream.str();
  std::cerr.flush();
}

#ifdef __native_client__

std::string GetGoogLogLevelByLogSeverity(internal::LogSeverity severity) {
  switch (severity) {
    case internal::LogSeverity::kDebug:
      return "FINE";
    case internal::LogSeverity::kInfo:
      return "INFO";
    case internal::LogSeverity::kWarning:
      return "WARNING";
    case internal::LogSeverity::kError:
      return "WARNING";
    case internal::LogSeverity::kFatal:
      return "SEVERE";
    default:
      // This should be never reached, but it's easier to provide a safe
      // default here.
      return "FINE";
  }
}

void EmitLogMessageToJavaScript(
    internal::LogSeverity severity, const std::string& message_text) {
  pp::VarDictionary message_data;
  message_data.Set(
      kDataLogLevelMessageKey, GetGoogLogLevelByLogSeverity(severity));
  message_data.Set(kDataTextMessageKey, message_text);
  pp::VarDictionary message;
  message.Set(kTypeMessageKey, kMessageType);
  message.Set(kDataMessageKey, message_data);

  const pp::Module* const pp_module = pp::Module::Get();
  if (pp_module) {
    const pp::Module::InstanceMap pp_instance_map =
        pp_module->current_instances();
    for (const std::pair<PP_Instance, pp::Instance*>& instance_map_item :
         pp_instance_map) {
      pp::Instance* const instance = instance_map_item.second;
      if (instance)
        instance->PostMessage(message);
    }
  }
}

#endif  // __native_client__

void EmitLogMessage(
    internal::LogSeverity severity, const std::string& message_text) {
  EmitLogMessageToStderr(severity, message_text);
#ifdef __native_client__
  EmitLogMessageToJavaScript(severity, message_text);
#endif  // __native_client__
}

}  // namespace

namespace internal {

LogMessage::LogMessage(LogSeverity severity)
    : severity_(severity) {}

LogMessage::~LogMessage() {
  EmitLogMessage(severity_, stream_.str());
  if (severity_ == internal::LogSeverity::kFatal)
    std::abort();
}

std::ostringstream& LogMessage::stream() {
  return stream_;
}

std::string MakeCheckFailedMessage(
    const std::string& stringified_condition,
    const std::string& file,
    int line,
    const std::string& function) {
  std::ostringstream stream;
  stream << "Check \"" << stringified_condition << "\" failed. File \"" <<
      file << "\", line " << line << ", function \"" << function << "\"";
  return stream.str();
}

std::string MakeNotreachedHitMessage(
    const std::string& file, int line, const std::string& function) {
  std::ostringstream stream;
  stream << "NOTREACHED hit at file \"" << file << "\", line " << line <<
      ", function \"" << function << "\"";
  return stream.str();
}

}  // namespace internal

}  // namespace google_smart_card
