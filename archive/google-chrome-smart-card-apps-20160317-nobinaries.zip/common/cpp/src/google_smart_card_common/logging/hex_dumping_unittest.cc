// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <stdint.h>

#include <string>

#include <gtest/gtest.h>

#include <google_smart_card_common/logging/hex_dumping.h>

namespace google_smart_card {

TEST(LoggingHexDumpTest, HexDumpByte) {
  EXPECT_EQ("0x00", HexDumpByte(static_cast<int8_t>(0)));
  EXPECT_EQ("0x00", HexDumpByte(static_cast<uint8_t>(0)));

  EXPECT_EQ("0x01", HexDumpByte(static_cast<int8_t>(1)));
  EXPECT_EQ("0x01", HexDumpByte(static_cast<uint8_t>(1)));

  EXPECT_EQ("0x64", HexDumpByte(static_cast<int8_t>(100)));
  EXPECT_EQ("0x64", HexDumpByte(static_cast<uint8_t>(100)));

  EXPECT_EQ("0xFF", HexDumpByte(static_cast<int8_t>(-1)));
  EXPECT_EQ("0xFF", HexDumpByte(static_cast<uint8_t>(255)));
}

TEST(LoggingHexDumpTest, HexDumpQuadlet) {
  EXPECT_EQ("0x00000000", HexDumpQuadlet(static_cast<int32_t>(0)));
  EXPECT_EQ("0x00000000", HexDumpQuadlet(static_cast<uint32_t>(0)));

  EXPECT_EQ("0xFFFFFFFF", HexDumpQuadlet(static_cast<int32_t>(-1)));
  EXPECT_EQ("0xFFFFFFFF", HexDumpQuadlet(static_cast<uint32_t>(-1)));
}

TEST(LoggingHexDumpTest, HexDumpOctlet) {
  EXPECT_EQ("0x0000000000000000", HexDumpOctlet(static_cast<int64_t>(0)));
  EXPECT_EQ("0x0000000000000000", HexDumpOctlet(static_cast<uint64_t>(0)));

  EXPECT_EQ("0xFFFFFFFFFFFFFFFF", HexDumpOctlet(static_cast<int64_t>(-1)));
  EXPECT_EQ("0xFFFFFFFFFFFFFFFF", HexDumpOctlet(static_cast<uint64_t>(-1)));
}

TEST(LoggingHexDumpTest, HexDumpInteger) {
  EXPECT_EQ("0x00", HexDumpInteger(static_cast<int8_t>(0)));
  EXPECT_EQ("0x00", HexDumpInteger(static_cast<uint8_t>(0)));

  EXPECT_EQ("0x00000000", HexDumpInteger(static_cast<int32_t>(0)));
  EXPECT_EQ("0x00000000", HexDumpInteger(static_cast<uint32_t>(0)));

  EXPECT_EQ("0x0000000000000000", HexDumpInteger(static_cast<int64_t>(0)));
  EXPECT_EQ("0x0000000000000000", HexDumpInteger(static_cast<uint64_t>(0)));
}

TEST(LoggingHexDumpTest, HexDumpUnknownSizeInteger) {
  EXPECT_EQ("0x00", HexDumpUnknownSizeInteger(static_cast<int64_t>(0)));
  EXPECT_EQ("0x00", HexDumpUnknownSizeInteger(static_cast<uint64_t>(0)));

  EXPECT_EQ("0xFF", HexDumpUnknownSizeInteger(static_cast<int64_t>(255)));
  EXPECT_EQ("0xFF", HexDumpUnknownSizeInteger(static_cast<uint64_t>(255)));

  EXPECT_EQ("0x00000100", HexDumpUnknownSizeInteger(static_cast<int64_t>(256)));
  EXPECT_EQ("0x00000100",
            HexDumpUnknownSizeInteger(static_cast<uint64_t>(256)));

  EXPECT_EQ("0xFFFFFFFF",
            HexDumpUnknownSizeInteger(static_cast<int64_t>((1LL << 32) - 1)));
  EXPECT_EQ(HexDumpUnknownSizeInteger(static_cast<uint64_t>((1LL << 32) - 1)),
            "0xFFFFFFFF");

  EXPECT_EQ("0x0000000100000000",
            HexDumpUnknownSizeInteger(static_cast<int64_t>(1LL << 32)));
  EXPECT_EQ("0x0000000100000000",
            HexDumpUnknownSizeInteger(static_cast<uint64_t>(1LL << 32)));

  EXPECT_EQ("0x7FFFFFFFFFFFFFFF",
            HexDumpUnknownSizeInteger(std::numeric_limits<int64_t>::max()));
  EXPECT_EQ("0xFFFFFFFFFFFFFFFF",
            HexDumpUnknownSizeInteger(static_cast<uint64_t>(-1)));

  EXPECT_EQ("0xFF", HexDumpUnknownSizeInteger(static_cast<int64_t>(-1)));
  EXPECT_EQ("0xFFFFFF00",
            HexDumpUnknownSizeInteger(static_cast<int64_t>(-256)));
  EXPECT_EQ("0x8000000000000000",
            HexDumpUnknownSizeInteger(std::numeric_limits<int64_t>::min()));
}

}  // namespace google_smart_card
