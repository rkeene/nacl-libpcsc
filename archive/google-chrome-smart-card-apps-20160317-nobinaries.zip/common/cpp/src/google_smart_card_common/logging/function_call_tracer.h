// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_LOGGING_FUNCTION_CALL_TRACER_H_
#define GOOGLE_SMART_CARD_COMMON_LOGGING_FUNCTION_CALL_TRACER_H_

#include <string>
#include <vector>

#include <google_smart_card_common/optional.h>

namespace google_smart_card {

// Helper class for implementing function call tracing - i.e. emitting debug log
// messages for function calls: first with the function input argument, then -
// with the function return value and the values of its output arguments.
class FunctionCallTracer final {
 public:
  explicit FunctionCallTracer(const std::string& function_name);

  void AddPassedArg(
      const std::string& name, const std::string& dumped_value);

  void AddReturnValue(const std::string& dumped_value);

  void AddReturnedArg(
      const std::string& name, const std::string& dumped_value);

  void LogEntrance() const;
  void LogEntrance(const std::string& logging_prefix) const;

  void LogExit() const;
  void LogExit(const std::string& logging_prefix) const;

 private:
  struct ArgNameWithValue {
    ArgNameWithValue(const std::string& name, const std::string& dumped_value);

    std::string name;
    std::string dumped_value;
  };

  static std::string DumpArgs(const std::vector<ArgNameWithValue>& args);

  const std::string function_name_;
  std::vector<ArgNameWithValue> passed_args_;
  optional<std::string> dumped_return_value_;
  std::vector<ArgNameWithValue> returned_args_;
};

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_LOGGING_FUNCTION_CALL_TRACER_H_
