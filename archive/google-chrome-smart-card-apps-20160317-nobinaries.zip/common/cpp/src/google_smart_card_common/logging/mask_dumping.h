// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// This file contains helper functions for dumping bit masks.

#ifndef GOOGLE_SMART_CARD_COMMON_LOGGING_MASK_DUMP_H_
#define GOOGLE_SMART_CARD_COMMON_LOGGING_MASK_DUMP_H_

#include <string>
#include <vector>

#include <google_smart_card_common/logging/hex_dumping.h>

namespace google_smart_card {

template <typename T>
struct MaskOptionValueWithName {
  MaskOptionValueWithName(T value, const std::string& name)
      : value(value),
        name(name) {}

  T value;
  std::string name;
};

template <typename T, typename ... Args>
inline std::string DumpMask(
    T value, const std::vector<MaskOptionValueWithName<T>>& options) {
  std::string result;
  for (const auto& option : options) {
    if (!(value & option.value))
      continue;
    if (!result.empty())
      result += '|';
    result += option.name;
    value &= ~option.value;
  }
  if (value) {
    if (!result.empty())
      result += '|';
    result += HexDumpInteger(value);
  }
  if (result.empty())
    return "0";
  return result;
}

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_LOGGING_MASK_DUMP_H_
