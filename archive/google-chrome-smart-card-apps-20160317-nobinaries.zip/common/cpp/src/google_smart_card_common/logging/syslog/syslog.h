// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Replacement of the syslog library, that allows to route all messages intended
// for syslog through the same logging infrastructure as the other NaCl code
// (see ../logging.h).
//
// The definitions in this header file follow the definitions in the standard
// <syslog.h> file.

#ifndef GOOGLE_SMART_CARD_COMMON_LOGGING_SYSLOG_SYSLOG_H_
#define GOOGLE_SMART_CARD_COMMON_LOGGING_SYSLOG_SYSLOG_H_

#ifdef __cplusplus
extern "C" {
#endif  // __cplusplus

/*
 * priorities/facilities are encoded into a single 32-bit quantity, where the
 * bottom 3 bits are the priority (0-7) and the top 28 bits are the facility
 * (0-big number).  Both the priorities and the facilities map roughly
 * one-to-one to strings in the syslogd(8) source code.  This mapping is
 * included in this file.
 *
 * priorities (these are ordered)
 */
#define LOG_EMERG   0   /* system is unusable */
#define LOG_ALERT   1   /* action must be taken immediately */
#define LOG_CRIT    2   /* critical conditions */
#define LOG_ERR     3   /* error conditions */
#define LOG_WARNING 4   /* warning conditions */
#define LOG_NOTICE  5   /* normal but significant condition */
#define LOG_INFO    6   /* informational */
#define LOG_DEBUG   7   /* debug-level messages */

/* Generate a log message using FMT string and option arguments.

   This function is a possible cancellation point and therefore not
   marked with __THROW.  */
void syslog(int priority, const char* format, ...);

#ifdef __cplusplus
}  // extern "C"
#endif  // __cplusplus

#endif  // GOOGLE_SMART_CARD_COMMON_LOGGING_SYSLOG_SYSLOG_H_
