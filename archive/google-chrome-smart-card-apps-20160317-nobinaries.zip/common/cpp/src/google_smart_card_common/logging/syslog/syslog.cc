// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/logging/syslog/syslog.h>

#include <cstdarg>
#include <string>

#include <google_smart_card_common/formatting.h>
#include <google_smart_card_common/logging/logging.h>

const char kLoggingPrefix[] = "[syslog] ";

void syslog(int priority, const char* format, ...) {
  va_list var_args;
  va_start(var_args, format);
  const std::string message =
      kLoggingPrefix +
      google_smart_card::FormatPrintfTemplate(format, var_args);
  va_end(var_args);

  switch (priority) {
    case LOG_EMERG:
    case LOG_ALERT:
    case LOG_CRIT:
    case LOG_ERR:
      GOOGLE_SMART_CARD_LOG_ERROR << message;
      return;
    case LOG_WARNING:
      GOOGLE_SMART_CARD_LOG_WARNING << message;
      return;
    case LOG_NOTICE:
    case LOG_INFO:
      GOOGLE_SMART_CARD_LOG_INFO << message;
      return;
    case LOG_DEBUG:
    default:
      GOOGLE_SMART_CARD_LOG_DEBUG << message;
      return;
  }
}
