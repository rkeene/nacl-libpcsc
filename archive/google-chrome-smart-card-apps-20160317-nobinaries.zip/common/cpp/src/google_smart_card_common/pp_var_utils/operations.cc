// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/pp_var_utils/operations.h>

namespace google_smart_card {

pp::VarArray SliceVarArray(
    const pp::VarArray& var, uint32_t begin_index, uint32_t count) {
  GOOGLE_SMART_CARD_CHECK(begin_index + count <= var.GetLength());
  pp::VarArray result;
  result.SetLength(count);
  for (uint32_t index = 0; index < count; ++index)
    SetVarArrayItem(&result, index, var.Get(begin_index + index));
  return result;
}

}  // namespace google_smart_card
