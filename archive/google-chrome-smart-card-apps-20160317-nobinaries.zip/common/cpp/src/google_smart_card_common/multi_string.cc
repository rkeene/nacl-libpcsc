// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/multi_string.h>

#include <google_smart_card_common/logging/logging.h>

namespace google_smart_card {

namespace {

std::vector<std::string> ExtractMultiStringElements(
    const char* multi_string, const char** multi_string_end) {
  std::vector<std::string> result;
  const char* current_begin = multi_string;
  while (*current_begin != '\0') {
    const std::string current_string(current_begin);
    result.push_back(current_string);
    current_begin += current_string.length() + 1;
  }
  *multi_string_end = current_begin + 1;
  return result;
}

}  // namespace

std::string CreateMultiString(
    const std::vector<std::string>& elements) {
  std::string result;
  for (const auto& element : elements) {
    GOOGLE_SMART_CARD_CHECK(element.find('\0') == std::string::npos);
    result += element;
    result += '\0';
  }
  result += '\0';
  return result;
}

std::vector<std::string> ExtractMultiStringElements(
    const std::string& multi_string) {
  GOOGLE_SMART_CARD_CHECK(multi_string.length());
  GOOGLE_SMART_CARD_CHECK(multi_string.back() == '\0');
  const char* multi_string_end;
  const std::vector<std::string> result = ExtractMultiStringElements(
      multi_string.c_str(), &multi_string_end);
  GOOGLE_SMART_CARD_CHECK(
      multi_string_end == multi_string.c_str() + multi_string.length());
  return result;
}

std::vector<std::string> ExtractMultiStringElements(
    const char* multi_string) {
  const char* multi_string_end;
  return ExtractMultiStringElements(multi_string, &multi_string_end);
}

}  // namespace google_smart_card
