// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_TUPLE_UNPACKING_H_
#define GOOGLE_SMART_CARD_COMMON_TUPLE_UNPACKING_H_

namespace google_smart_card {

// Helper template class that holds a compile-time integer sequence as its
// template parameter pack.
template <size_t ... Sequence>
struct ArgIndexes {};

namespace internal {

template <size_t ArgCounter, size_t ... Sequence>
struct ArgIndexesGenerator
    : ArgIndexesGenerator<ArgCounter - 1, ArgCounter - 1, Sequence...> {};

template <size_t ... Sequence>
struct ArgIndexesGenerator<0, Sequence...> {
  using result = ArgIndexes<Sequence...>;
};

}  // namespace internal

// Generate compile-time sequence of argument indexes that can be used for the
// extraction of std::tuple elements.
//
// In essense, MakeArgIndexes<X> is an ArgIndexes<0, 1, 2, ..., X - 1>.
template <size_t ArgCount>
using MakeArgIndexes = typename internal::ArgIndexesGenerator<ArgCount>::result;

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_TUPLE_UNPACKING_H_
