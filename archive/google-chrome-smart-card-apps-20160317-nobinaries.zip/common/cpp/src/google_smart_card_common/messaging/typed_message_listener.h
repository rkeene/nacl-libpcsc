// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_MESSAGING_TYPED_MESSAGE_LISTENER_H_
#define GOOGLE_SMART_CARD_COMMON_MESSAGING_TYPED_MESSAGE_LISTENER_H_

#include <string>

#include <ppapi/cpp/var.h>

namespace google_smart_card {

// The abstract class for a listener of Pepper messages having a specific type.
//
// For the usage details please see the TypedMessageRouter class.
class TypedMessageListener {
 public:
  virtual ~TypedMessageListener() = default;

  // The type of the Pepper messages that have to be listened.
  //
  // Note: it is assumed that this method always returns the same value for the
  // same TypedMessageListener object.
  virtual std::string GetListenedMessageType() const = 0;

  // Called when a message of the requested type is received. The data argument
  // contains the whole message contents except its type key (for the details
  // please refer to the typed_message.h file).
  //
  // Returns whether the message was handled.
  virtual bool OnTypedMessageReceived(const pp::Var& data) = 0;
};

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_MESSAGING_TYPED_MESSAGE_LISTENER_H_
