// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/messaging/typed_message_router.h>

#include <algorithm>

#include <google_smart_card_common/logging/logging.h>
#include <google_smart_card_common/messaging/typed_message.h>

namespace google_smart_card {

void TypedMessageRouter::AddRoute(TypedMessageListener* listener) {
  const std::unique_lock<std::mutex> lock(mutex_);

  const bool is_new_route_added = route_map_.emplace(
      listener->GetListenedMessageType(), listener).second;
  GOOGLE_SMART_CARD_CHECK(is_new_route_added);
}

void TypedMessageRouter::RemoveRoute(TypedMessageListener* listener) {
  const std::unique_lock<std::mutex> lock(mutex_);

  const auto route_map_iter = route_map_.find(
      listener->GetListenedMessageType());
  GOOGLE_SMART_CARD_CHECK(route_map_iter != route_map_.end());
  GOOGLE_SMART_CARD_CHECK(route_map_iter->second == listener);
  route_map_.erase(route_map_iter);
}

bool TypedMessageRouter::OnMessageReceived(const pp::Var& message) {
  std::string type;
  pp::Var data;
  if (!ParseTypedMessage(message, &type, &data))
    return false;

  TypedMessageListener* const listener = FindListenerByType(type);
  if (!listener)
    return false;

  return listener->OnTypedMessageReceived(data);
}

TypedMessageListener* TypedMessageRouter::FindListenerByType(
    const std::string& message_type) const {
  const std::unique_lock<std::mutex> lock(mutex_);

  const auto route_map_iter = route_map_.find(message_type);
  if (route_map_iter == route_map_.end())
    return nullptr;
  return route_map_iter->second;
}

}  // namespace google_smart_card
