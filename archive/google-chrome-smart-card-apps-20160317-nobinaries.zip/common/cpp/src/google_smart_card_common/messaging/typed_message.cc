// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/messaging/typed_message.h>

#include <ppapi/cpp/var_dictionary.h>

#include <google_smart_card_common/pp_var_utils/construction.h>
#include <google_smart_card_common/pp_var_utils/extraction.h>

const char kTypeMessageKey[] = "type";
const char kDataMessageKey[] = "data";

namespace google_smart_card {

bool ParseTypedMessage(
    const pp::Var& message, std::string* type, pp::Var* data) {
  std::string error_message;
  pp::VarDictionary message_dict;
  if (!VarAs(message, &message_dict, &error_message))
    return false;
  return VarDictValuesExtractor(message_dict)
      .Extract(kTypeMessageKey, type)
      .Extract(kDataMessageKey, data)
      .GetSuccessWithNoExtraKeysAllowed(&error_message);
}

pp::Var MakeTypedMessage(const std::string& type, const pp::Var& data) {
  return VarDictBuilder()
      .Add(kTypeMessageKey, type).Add(kDataMessageKey, data).Result();
}

}  // namespace google_smart_card
