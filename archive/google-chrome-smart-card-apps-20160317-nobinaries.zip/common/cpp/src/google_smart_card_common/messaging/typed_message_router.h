// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_MESSAGING_TYPED_MESSAGE_ROUTER_H_
#define GOOGLE_SMART_CARD_COMMON_MESSAGING_TYPED_MESSAGE_ROUTER_H_

#include <mutex>
#include <string>
#include <unordered_map>

#include <ppapi/cpp/var.h>

#include <google_smart_card_common/messaging/message_listener.h>
#include <google_smart_card_common/messaging/typed_message_listener.h>

namespace google_smart_card {

// The router that handles incoming messages by routing them to the correct
// listener.
//
// The routing is based on the message type key (which has to be a string): the
// listener whose GetListenedMessageType method returns the same string will
// receive the message.
// If there was no corresponding listener found, or if the message has a wrong
// format, then the message is left unhandled (and false is returned from the
// OnMessageReceived method).
//
// The class is generally thread-safe. Note that, however, it's the consumer's
// responsibility to deal with the situations when a listener is removed at the
// same time when a message routed to it is being processed (in that case the
// listener may receive the message even after the RemoveRoute method was
// called).
class TypedMessageRouter final : public MessageListener {
 public:
  // Adds a new listener, which will handle all messages having the type equal
  // to the GetListenedMessageType return value.
  //
  // Asserts that no listener has already been registered for the same type.
  void AddRoute(TypedMessageListener* listener);

  // Removes a previously added listener.
  //
  // Asserts that the listener was actually added.
  void RemoveRoute(TypedMessageListener* listener);

  // MessageListener implementation
  bool OnMessageReceived(const pp::Var& message) override;

 private:
  TypedMessageListener* FindListenerByType(
      const std::string& message_type) const;

  mutable std::mutex mutex_;
  std::unordered_map<std::string, TypedMessageListener*> route_map_;
};

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_MESSAGING_TYPED_MESSAGE_ROUTER_H_
