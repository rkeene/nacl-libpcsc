// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_MESSAGING_MESSAGE_LISTENER_H_
#define GOOGLE_SMART_CARD_COMMON_MESSAGING_MESSAGE_LISTENER_H_

#include <ppapi/cpp/var.h>

namespace google_smart_card {

// The abstract class for a Pepper message listener.
class MessageListener {
 public:
  virtual ~MessageListener() = default;

  // Called when a message is received.
  //
  // Returns whether the message was handled.
  virtual bool OnMessageReceived(const pp::Var& message) = 0;
};

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_MESSAGING_MESSAGE_LISTENER_H_
