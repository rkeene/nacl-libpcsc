// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/requesting/remote_call_adaptor.h>

#include <utility>

#include <ppapi/cpp/var_dictionary.h>

#include <google_smart_card_common/requesting/remote_call_message.h>

namespace google_smart_card {

RemoteCallAdaptor::RemoteCallAdaptor(Requester* requester)
    : requester_(requester) {
  GOOGLE_SMART_CARD_CHECK(requester_);
}

GenericRequestResult RemoteCallAdaptor::PerformSyncRequest(
    const std::string& function_name, const pp::VarArray& converted_arguments) {
  return requester_->PerformSyncRequest(MakeRemoteCallRequestPayload(
      function_name, converted_arguments));
}

void RemoteCallAdaptor::StartAsyncRequest(
    const std::string& function_name,
    const pp::VarArray& converted_arguments,
    AsyncRequestCallback callback,
    AsyncRequest* async_request) {
  return requester_->StartAsyncRequest(
      MakeRemoteCallRequestPayload(function_name, converted_arguments),
      callback,
      async_request);
}

}  // namespace google_smart_card
