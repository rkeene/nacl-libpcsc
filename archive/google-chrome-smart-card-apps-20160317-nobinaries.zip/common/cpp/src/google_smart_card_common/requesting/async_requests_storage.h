// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_REQUESTING_ASYNC_REQUESTS_STORAGE_H_
#define GOOGLE_SMART_CARD_COMMON_REQUESTING_ASYNC_REQUESTS_STORAGE_H_

#include <memory>
#include <mutex>
#include <unordered_map>
#include <vector>

#include <google_smart_card_common/requesting/async_request.h>
#include <google_smart_card_common/requesting/request_id.h>

namespace google_smart_card {

// Storage for asynchronous request states, that keeps them in a mapping based
// on a generated sequence of identifiers.
//
// This class is thread-safe.
class AsyncRequestsStorage final {
 public:
  AsyncRequestsStorage();

  // Adds a new asynchronous request state under a unique identifier and returns
  // this identifier.
  RequestId Push(std::shared_ptr<AsyncRequestState> async_request_state);

  // Extracts the asynchronous request state that corresponds to the specified
  // identifier.
  //
  // Returns null if the specified request identifier is not present.
  std::shared_ptr<AsyncRequestState> Pop(RequestId request_id);

  // Extracts all stored asynchronous request states.
  //
  // The order of the returned request states is unspecified.
  std::vector<std::shared_ptr<AsyncRequestState>> PopAll();

 private:
  std::mutex mutex_;
  RequestId next_free_request_id_;
  std::unordered_map<RequestId, const std::shared_ptr<AsyncRequestState>>
  state_map_;
};

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_REQUESTING_ASYNC_REQUESTS_STORAGE_H_
