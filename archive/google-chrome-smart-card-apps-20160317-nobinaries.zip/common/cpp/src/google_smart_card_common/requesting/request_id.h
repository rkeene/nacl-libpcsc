// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUEST_ID_H_
#define GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUEST_ID_H_

#include <stdint.h>

namespace google_smart_card {

// Request identifier type.
//
// Request identifiers are used when serializing requests into messages and for
// tracking of the sent requests.
using RequestId = int64_t;

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUEST_ID_H_
