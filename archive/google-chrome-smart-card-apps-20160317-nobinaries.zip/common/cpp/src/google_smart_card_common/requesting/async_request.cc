// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/requesting/async_request.h>

#include <utility>

#include <google_smart_card_common/logging/logging.h>

namespace google_smart_card {

AsyncRequestState::AsyncRequestState(AsyncRequestCallback callback)
    : callback_(callback) {}

bool AsyncRequestState::SetResult(GenericRequestResult request_result) {
  if (!is_callback_called_.test_and_set()) {
    callback_(std::move(request_result));
    return true;
  }
  return false;
}

AsyncRequest::AsyncRequest() {}

AsyncRequest::AsyncRequest(std::shared_ptr<AsyncRequestState> state)
    : state_(state) {
  GOOGLE_SMART_CARD_CHECK(state_);
}

bool AsyncRequest::Cancel() {
  const std::shared_ptr<AsyncRequestState> state = std::atomic_load(&state_);
  GOOGLE_SMART_CARD_CHECK(state);
  return state->SetResult(GenericRequestResult::CreateCanceled());
}

AsyncRequest& AsyncRequest::operator=(const AsyncRequest& other) {
  std::atomic_store(&state_, other.state_);
  return *this;
}

}  // namespace google_smart_card
