// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// This file contains definitions for describing a result of request.

#ifndef GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUEST_RESULT_H_
#define GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUEST_RESULT_H_

#include <string>
#include <utility>

#include <ppapi/cpp/var.h>

#include <google_smart_card_common/logging/logging.h>
#include <google_smart_card_common/optional.h>

namespace google_smart_card {

// Request status that describes the request outcome, which can be either of the
// following:
// * successfully finished,
// * failed due to some error,
// * canceled by consumer's request.
enum class RequestResultStatus {
  kSucceeded,
  kFailed,
  kCanceled,
};

namespace internal {

extern const char kRequestCanceledErrorMessage[];

}  // namespace internal

// Request result consists of:
// * request result status (RequestResultStatus enum value),
// * error message (only when the status is RequestResultStatus::kFailed or
//   RequestResultStatus::kCanceled),
// * request result payload (only when the status is
//   RequestResultStatus::kSucceeded).
template <typename PayloadType>
class RequestResult final {
 public:
  RequestResult()
      : status_(RequestResultStatus::kFailed) {}

  static RequestResult CreateSuccessful(PayloadType payload) {
    return RequestResult(PayloadType(std::move(payload)));
  }

  static RequestResult CreateFailed(const std::string& error_message) {
    return CreateUnsuccessful(RequestResultStatus::kFailed, error_message);
  }

  static RequestResult CreateCanceled() {
    return CreateUnsuccessful(
        RequestResultStatus::kCanceled, internal::kRequestCanceledErrorMessage);
  }

  static RequestResult CreateUnsuccessful(
      RequestResultStatus status, const std::string& error_message) {
    return RequestResult(status, error_message);
  }

  RequestResultStatus status() const {
    return status_;
  }

  bool is_successful() const {
    return status_ == RequestResultStatus::kSucceeded;
  }

  std::string error_message() const {
    GOOGLE_SMART_CARD_CHECK(status_ == RequestResultStatus::kFailed ||
                            status_ == RequestResultStatus::kCanceled);
    GOOGLE_SMART_CARD_CHECK(error_message_);
    return *error_message_;
  }

  const PayloadType& payload() const {
    GOOGLE_SMART_CARD_CHECK(status_ == RequestResultStatus::kSucceeded);
    GOOGLE_SMART_CARD_CHECK(payload_);
    return *payload_;
  }

 private:
  explicit RequestResult(PayloadType payload)
      : status_(RequestResultStatus::kSucceeded),
        payload_(payload) {}

  RequestResult(RequestResultStatus status, const std::string& error_message)
      : status_(status),
        error_message_(error_message) {
    GOOGLE_SMART_CARD_CHECK(status != RequestResultStatus::kSucceeded);
  }

  RequestResultStatus status_;
  optional<std::string> error_message_;
  optional<PayloadType> payload_;
};

using GenericRequestResult = RequestResult<pp::Var>;

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUEST_RESULT_H_
