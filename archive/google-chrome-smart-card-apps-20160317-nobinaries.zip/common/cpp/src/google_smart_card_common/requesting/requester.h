// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUESTER_H_
#define GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUESTER_H_

#include <string>

#include <ppapi/cpp/var.h>

#include <google_smart_card_common/requesting/async_request.h>
#include <google_smart_card_common/requesting/async_requests_storage.h>
#include <google_smart_card_common/requesting/request_id.h>
#include <google_smart_card_common/requesting/request_result.h>

namespace google_smart_card {

// An abstract requester which is an entity for sending some requests and
// receiving their results.
//
// Note that it's generally safe to keep the AsyncRequest objects returned by
// the methods of this class even after destroying of the requester (however,
// all requests that were still waiting for their responses will be anyway
// marked as failed).
class Requester {
 public:
  // Creates the requester with the specified name.
  //
  // The requester name exists for tagging the sent requests in some way so that
  // the appropriate request handler can be picked on the other end (see e.g.
  // the common/requesting/request_receiver.h file) and that the response can
  // return back to this requester properly. So, generally, the requester names
  // have to be unique.
  explicit Requester(const std::string& name);

  // Destroys the requester.
  //
  // All requests still waiting for the responses are marked as failed
  // immediately.
  virtual ~Requester();

  std::string name() const {
    return name_;
  }

  // Detaches the requester, which may prevent it from sending new requests (new
  // requests may immediately finish with the RequestResultStatus::kFailed
  // state) and/or from receiving results of already sent ones.
  //
  // This function is safe to be called from any thread.
  virtual void Detach() {}

  // Starts an asynchronous request with the given payload and the given
  // callback, which will be executed once the request finishes (either
  // successfully or not).
  //
  // Note: the callback may be executed on a different thread than the thread
  // used for sending the request.
  //
  // Note: It's also possible that the callback is executed synchronously during
  // this method call (e.g. when a fatal error occured that prevents the
  // implementation from starting the asynchronous request).
  AsyncRequest StartAsyncRequest(
      const pp::Var& payload, AsyncRequestCallback callback);

  // Starts an asynchronous request with the given payload and the given
  // callback, which will be executed once the request finishes (either
  // successfully or not).
  //
  // The resulting AsyncRequest object will be assigned into the async_request
  // argument. This allows to provide the consumer with the AsyncRequest object
  // before the callback is executed (that can simplify the consumer's logic in
  // some cases).
  //
  // Note: the callback may be executed on a different thread than the thread
  // used for sending the request.
  //
  // Note: It's also possible that the callback is executed synchronously during
  // this method call (e.g. when a fatal error occured that prevents the
  // implementation from starting the asynchronous request).
  virtual void StartAsyncRequest(
      const pp::Var& payload,
      AsyncRequestCallback callback,
      AsyncRequest* async_request) = 0;

  // Performs a synchronous request, blocking current thread until the result is
  // received.
  //
  // It's guaranteed that the returned result cannot have the
  // RequestResultStatus::kCanceled state.
  virtual GenericRequestResult PerformSyncRequest(const pp::Var& payload);

 protected:
  // Creates and stores internally a new asynchronous request state, returning
  // its public proxy object (AsyncRequest object) and its generated request
  // identifier.
  AsyncRequest CreateAsyncRequest(
      const pp::Var& payload,
      AsyncRequestCallback callback,
      RequestId* request_id);

  // Finds the request state by the specified request identifier and sets its
  // result (which, in turn, runs the callback if it has not been executed yet).
  //
  // After calling this function, the request state is not tracked by this
  // requester anymore.
  //
  // Returns whether the request with the specified identifier was found.
  bool SetAsyncRequestResult(
      RequestId request_id, GenericRequestResult request_result);

 private:
  const std::string name_;
  AsyncRequestsStorage async_requests_storage_;
};

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUESTER_H_
