// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUEST_HANDLER_H_
#define GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUEST_HANDLER_H_

#include <ppapi/cpp/var.h>

#include <google_smart_card_common/requesting/request_receiver.h>

namespace google_smart_card {

// The abstract class for a handler of incoming requests.
//
// The handler is the component that is actually executing the requests.
//
// In order to receive the requests, the handler has to be associated with one
// or multiple request receivers (see the common/requesting/request_receiver.h
// file).
class RequestHandler {
 public:
  virtual ~RequestHandler() = default;

  // Handles the request with the specified payload, and with the specified
  // callback that can be used to send the request results back.
  //
  // Note that, generally speaking, this function should not block for a very
  // long periods of time (and probably not do any waiting on the incoming
  // Pepper messages at all), as the request receiver calls this method
  // synchronously and, depending on the type of channel it uses, may lead to
  // freezes and deadlocks.
  virtual void HandleRequest(
      const pp::Var& payload,
      RequestReceiver::ResultCallback result_callback) = 0;
};

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_REQUESTING_REQUEST_HANDLER_H_
