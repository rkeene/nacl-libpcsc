// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/requesting/request_receiver.h>

#include <utility>

#include <google_smart_card_common/logging/logging.h>
#include <google_smart_card_common/requesting/request_handler.h>

namespace google_smart_card {

RequestReceiver::RequestReceiver(
    const std::string& name, RequestHandler* handler)
    : name_(name),
      handler_(handler) {
  GOOGLE_SMART_CARD_CHECK(handler_);
}

std::string RequestReceiver::name() const {
  return name_;
}

void RequestReceiver::HandleRequest(
    RequestId request_id, const pp::Var& payload) {
  handler_->HandleRequest(payload, MakeResultCallback(request_id));
}

RequestReceiver::ResultCallbackImpl::ResultCallbackImpl(
    RequestId request_id, std::weak_ptr<RequestReceiver> request_receiver)
    : request_id_(request_id),
      request_receiver_(request_receiver) {}

void RequestReceiver::ResultCallbackImpl::operator()(
    GenericRequestResult request_result) {
  const std::shared_ptr<RequestReceiver> locked_request_receiver(
      request_receiver_.lock());
  if (locked_request_receiver)
    locked_request_receiver->PostResult(request_id_, std::move(request_result));
}

RequestReceiver::ResultCallback RequestReceiver::MakeResultCallback(
    RequestId request_id) {
  return ResultCallbackImpl(
      request_id, std::weak_ptr<RequestReceiver>(shared_from_this()));
}

}  // namespace google_smart_card
