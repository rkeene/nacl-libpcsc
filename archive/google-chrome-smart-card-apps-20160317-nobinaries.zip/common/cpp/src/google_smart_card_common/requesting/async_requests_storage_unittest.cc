// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <memory>
#include <thread>
#include <vector>

#include <gtest/gtest.h>

#include <google_smart_card_common/requesting/async_request.h>
#include <google_smart_card_common/requesting/async_requests_storage.h>
#include <google_smart_card_common/requesting/request_id.h>
#include <google_smart_card_common/requesting/request_result.h>

namespace google_smart_card {

namespace {

class TestAsyncRequestCallback {
 public:
  void operator()(GenericRequestResult) {}
};

}  // namespace

TEST(RequestingAsyncRequestsStorageTest, Basic) {
  AsyncRequestsStorage storage;

  // Initially the storage contains no requests
  EXPECT_FALSE(storage.Pop(static_cast<RequestId>(0)));
  EXPECT_TRUE(storage.PopAll().empty());

  // Two new request states are added, and they receive different identifiers
  std::shared_ptr<AsyncRequestState> request_1_state(new AsyncRequestState(
      TestAsyncRequestCallback()));
  const RequestId request_1_id = storage.Push(request_1_state);
  std::shared_ptr<AsyncRequestState> request_2_state(new AsyncRequestState(
      TestAsyncRequestCallback()));
  const RequestId request_2_id = storage.Push(request_2_state);
  EXPECT_NE(request_1_id, request_2_id);

  // Extraction of the two requests leaves the storage in an empty state again
  EXPECT_EQ(request_1_state, storage.Pop(request_1_id));
  EXPECT_EQ(request_2_state, storage.Pop(request_2_id));
  EXPECT_FALSE(storage.Pop(request_1_id));
  EXPECT_FALSE(storage.Pop(request_2_id));
  EXPECT_TRUE(storage.PopAll().empty());

  // Two new added requests receive identifiers distinct from the previous
  // requests' identifiers
  std::shared_ptr<AsyncRequestState> request_3_state(new AsyncRequestState(
      TestAsyncRequestCallback()));
  const RequestId request_3_id = storage.Push(request_3_state);
  EXPECT_NE(request_1_id, request_3_id);
  EXPECT_NE(request_2_id, request_3_id);
  std::shared_ptr<AsyncRequestState> request_4_state(new AsyncRequestState(
      TestAsyncRequestCallback()));
  const RequestId request_4_id = storage.Push(request_4_state);
  EXPECT_NE(request_1_id, request_4_id);
  EXPECT_NE(request_2_id, request_4_id);
  EXPECT_NE(request_3_id, request_4_id);

  // The two currently added requests can be extracted from the storage, but
  // they are returned not in any specific order
  const std::vector<std::shared_ptr<AsyncRequestState>> requests =
      storage.PopAll();
  ASSERT_EQ(static_cast<size_t>(2), requests.size());
  EXPECT_TRUE(
      requests[0] == request_3_state && requests[1] == request_4_state ||
      requests[0] == request_4_state && requests[1] == request_3_state);
  EXPECT_TRUE(storage.PopAll().empty());
  EXPECT_FALSE(storage.Pop(request_3_id));
  EXPECT_FALSE(storage.Pop(request_4_id));
}

TEST(RequestingAsyncRequestsStorageTest, MultiThreading) {
  const int kThreadCount = 10;
  const int kIterationCount = 10 * 1000;

  AsyncRequestsStorage storage;

  std::vector<std::thread> threads;
  for (int thread_index = 0; thread_index < kThreadCount; ++thread_index) {
    threads.emplace_back([&storage, thread_index] {
      std::vector<RequestId> request_ids;
      for (int iteration = 0; iteration < kIterationCount; ++iteration) {
        request_ids.push_back(storage.Push(std::make_shared<AsyncRequestState>(
            TestAsyncRequestCallback())));
      }
      if (thread_index % 2 == 0) {
        for (auto request_id : request_ids)
          storage.Pop(request_id);
      } else {
        storage.PopAll();
      }
    });
  }

  for (int thread_index = 0; thread_index < kThreadCount; ++thread_index)
    threads[thread_index].join();

  EXPECT_TRUE(storage.PopAll().empty());
}

}  // namespace google_smart_card
