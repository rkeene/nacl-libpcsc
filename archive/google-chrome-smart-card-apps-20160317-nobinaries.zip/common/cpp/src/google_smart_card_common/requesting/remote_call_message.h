// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef GOOGLE_SMART_CARD_COMMON_REQUESTING_REMOTE_CALL_MESSAGE_H_
#define GOOGLE_SMART_CARD_COMMON_REQUESTING_REMOTE_CALL_MESSAGE_H_

#include <string>

#include <ppapi/cpp/var.h>
#include <ppapi/cpp/var_array.h>

namespace google_smart_card {

// Constructs the message data payload of the remote call request, containing
// the specified function name and the array of the function arguments.
pp::Var MakeRemoteCallRequestPayload(
    const std::string& function_name, const pp::VarArray& arguments);

// Parses the message data payload of the remote call request, extracting the
// function name and the array of the function arguments.
bool ParseRemoteCallRequestPayload(
    const pp::Var& request_payload,
    std::string* function_name,
    pp::VarArray* arguments);

// Generates a human-readable debug dump of the remote call request.
std::string DebugDumpRemoteCallRequest(
    const std::string& function_name, const pp::VarArray& arguments);

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_REQUESTING_REMOTE_CALL_MESSAGE_H_
