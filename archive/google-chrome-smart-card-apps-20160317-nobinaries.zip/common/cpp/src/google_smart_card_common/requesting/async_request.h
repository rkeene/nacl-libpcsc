// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// This file contains definitions of types related to keeping the asynchronous
// requests state.

#ifndef GOOGLE_SMART_CARD_COMMON_REQUESTING_ASYNC_REQUEST_H_
#define GOOGLE_SMART_CARD_COMMON_REQUESTING_ASYNC_REQUEST_H_

#include <atomic>
#include <functional>
#include <memory>
#include <string>

#include <google_smart_card_common/requesting/request_result.h>

namespace google_smart_card {

// Consumer-provided callback that will be called once the asynchronous request
// finishes (either successfully or not).
using AsyncRequestCallback = std::function<
    void(GenericRequestResult request_result)>;

// Internal state of an asynchronous request.
//
// Usually exists as a ref-counted object hidden from the consumer under the
// AsyncRequest class.
class AsyncRequestState final {
 public:
  explicit AsyncRequestState(AsyncRequestCallback callback);

  // Sets the result of the request, unless it was already set before.
  //
  // If the result was successfully set, then the callback passed to the class
  // constructor is executed.
  bool SetResult(GenericRequestResult request_result);

 private:
  const AsyncRequestCallback callback_;
  std::atomic_flag is_callback_called_ = ATOMIC_FLAG_INIT;
};

// This class contains the interface of an asynchronous request that is exposed
// to consumers.
//
// Note that this class has no methods for obtaining the request result: the
// results are delivered through the AsyncRequestCallback callback supplied when
// the request was sent.
class AsyncRequest final {
 public:
  AsyncRequest();
  explicit AsyncRequest(std::shared_ptr<AsyncRequestState> state);

  // Thread-safe assignment operator.
  AsyncRequest& operator=(const AsyncRequest& other);

  // Cancels the request in a thread-safe manner.
  //
  // Returns whether the cancellation was successful. The cancellation fails if
  // the request has already finished with some result (including, but not
  // limiting to, another cancellation).
  bool Cancel();

 private:
  std::shared_ptr<AsyncRequestState> state_;
};

}  // namespace google_smart_card

#endif  // GOOGLE_SMART_CARD_COMMON_REQUESTING_ASYNC_REQUEST_H_
