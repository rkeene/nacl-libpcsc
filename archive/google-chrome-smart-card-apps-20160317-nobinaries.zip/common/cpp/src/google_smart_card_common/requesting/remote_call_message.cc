// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <google_smart_card_common/requesting/remote_call_message.h>

#include <ppapi/cpp/var_dictionary.h>

#include <google_smart_card_common/logging/logging.h>
#include <google_smart_card_common/pp_var_utils/construction.h>
#include <google_smart_card_common/pp_var_utils/debug_dump.h>
#include <google_smart_card_common/pp_var_utils/extraction.h>

const char kFunctionNameMessageField[] = "function_name";
const char kFunctionArgumentsMessageField[] = "arguments";

namespace google_smart_card {

pp::Var MakeRemoteCallRequestPayload(
    const std::string& function_name, const pp::VarArray& arguments) {
  return VarDictBuilder()
      .Add(kFunctionNameMessageField, function_name)
      .Add(kFunctionArgumentsMessageField, arguments)
      .Result();
}

bool ParseRemoteCallRequestPayload(
    const pp::Var& request_payload,
    std::string* function_name,
    pp::VarArray* arguments) {
  std::string error_message;
  pp::VarDictionary request_payload_dict;
  if (!VarAs(request_payload, &request_payload_dict, &error_message))
    return false;
  return VarDictValuesExtractor(request_payload_dict)
      .Extract(kFunctionNameMessageField, function_name)
      .Extract(kFunctionArgumentsMessageField, arguments)
      .GetSuccessWithNoExtraKeysAllowed(&error_message);
}

std::string DebugDumpRemoteCallRequest(
    const std::string& function_name, const pp::VarArray& arguments) {
  std::string dumped_arguments = DebugDumpVar(arguments);
  GOOGLE_SMART_CARD_CHECK(!dumped_arguments.empty());
  GOOGLE_SMART_CARD_CHECK(dumped_arguments.front() == '[');
  GOOGLE_SMART_CARD_CHECK(dumped_arguments.back() == ']');
  dumped_arguments.front() = '(';
  dumped_arguments.back() = ')';
  return function_name + dumped_arguments;
}

}  // namespace google_smart_card
