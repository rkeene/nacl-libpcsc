#!/bin/sh -e

# Copyright 2015 The Chromium Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.


DEPOT_TOOLS_REPOSITORY_URL="https://chromium.googlesource.com/chromium/tools/depot_tools.git"

NACL_SDK_ARCHIVE_URL="https://storage.googleapis.com/nativeclient-mirror/nacl/nacl_sdk/nacl_sdk.zip"
NACL_SDK_VERSION="47"

WEBPORTS_REPOSITORY_URL="https://chromium.googlesource.com/webports.git"
WEBPORTS_TARGETS="glibc-compat boost openssl"
