#!/usr/bin/env bash

# Copyright 2015 The Chromium Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.


set -eu


PATHS_TO_CLEAN="
  activate
  depot_tools
  nacl_sdk
  webports
"


SCRIPTPATH=$(dirname $(realpath ${0}))
cd ${SCRIPTPATH}

for path in ${PATHS_TO_CLEAN}; do
  rm -rf ${path}
done
