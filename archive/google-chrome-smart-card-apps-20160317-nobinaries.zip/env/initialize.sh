#!/usr/bin/env bash

# Copyright 2015 The Chromium Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.


set -eu


log_message() {
  local message=${1}

  echo -e "\033[33;32m${message}\033[0m"
}

log_error_message() {
  local message=${1}

  echo -e "\033[33;31m${message}\033[0m"
}

initialize_depot_tools() {
  log_message "Installing depot_tools..."
  rm -rf ./depot_tools
  git clone "${DEPOT_TOOLS_REPOSITORY_URL}" depot_tools
  PATH="${SCRIPTPATH}/depot_tools:${PATH}"
  log_message "depot_tools were installed successfully."
}

initialize_nacl_sdk() {
  log_message "Installing Native Client SDK (version ${NACL_SDK_VERSION})..."
  curl -o nacl_sdk.zip "${NACL_SDK_ARCHIVE_URL}"
  rm -rf nacl_sdk
  unzip -q nacl_sdk.zip
  rm nacl_sdk.zip
  nacl_sdk/naclsdk install pepper_${NACL_SDK_VERSION}
  export NACL_SDK_ROOT="${SCRIPTPATH}/nacl_sdk/pepper_${NACL_SDK_VERSION}"
  log_message "Native Client SDK was installed successfully."
}

initialize_webports() {
  log_message "Installing webports (with building the following libraries: ${WEBPORTS_TARGETS})..."
  rm -rf webports
  mkdir webports
  cd ${SCRIPTPATH}/webports
  gclient config --unmanaged --name=src "${WEBPORTS_REPOSITORY_URL}"
  gclient sync --with_branch_heads
  cd ${SCRIPTPATH}/webports/src
  git checkout -b pepper_${NACL_SDK_VERSION} origin/pepper_${NACL_SDK_VERSION}
  gclient sync
  local failed_targets=
  for target in ${WEBPORTS_TARGETS}; do
    if ! NACL_ARCH=pnacl TOOLCHAIN=pnacl make ${target} ; then
      local failed_targets="${failed_targets} ${target}"
    fi
  done
  cd ${SCRIPTPATH}
  if [[ ${failed_targets} ]]; then
    log_error_message "webports were installed, but the following libraries failed to build:${failed_targets}. You have to fix them manually. Continuing the initialization script..."
  else
    log_message "webports were installed successfully."
  fi
}

create_activate_script() {
  log_message "Creating \"activate\" script..."
  echo "export NACL_SDK_ROOT=${NACL_SDK_ROOT}" > activate
  log_message "\"activate\" script was created successfully. Run \". $(dirname ${0})/activate\" in order to trigger all necessary environment definitions."
}


SCRIPTPATH=$(dirname $(realpath ${0}))
cd ${SCRIPTPATH}

. ./constants.sh

initialize_depot_tools
initialize_nacl_sdk
initialize_webports
create_activate_script
