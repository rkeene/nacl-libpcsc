#!/usr/bin/env bash

# Copyright 2015 The Chromium Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.


set -eu


DIRS="
	common/cpp/build
	third_party/libusb/naclport/build
	third_party/ccid/naclport/build
	third_party/pcsc-lite/naclport/common/build
	third_party/pcsc-lite/naclport/server/build
	third_party/pcsc-lite/naclport/server_clients_management/build
	third_party/pcsc-lite/naclport/cpp_demo/build
	smart_card_connector_app/build
	example_js_smart_card_client_app/build
	third_party/pcsc-lite/naclport/cpp_client/build
	example_cpp_smart_card_client_app/build
	example_js_standalone_smart_card_client_library"

BUILT_APP_PACKAGES_DIR="built_app_packages"

CONFIGS="Release Debug"


log_message() {
	local message=${1}

	echo -e "\033[33;32m${message}\033[0m"
}

clean_dir_with_all_configs() {
	local dir=${1}

	log_message "Cleaning \"${dir}\"..."
	for config in ${CONFIGS}; do
		CONFIG=${config} make -C ${dir} clean || true
	done
}

clean_built_app_packages() {
	log_message "Cleaning built App packages..."
	rm -rf ${BUILT_APP_PACKAGES_DIR}
}

clean_env() {
	log_message "Cleaning env..."
	env/clean.sh || true
}


SCRIPTPATH=$(dirname $(realpath ${0}))
cd ${SCRIPTPATH}

for dir in ${DIRS}; do
	clean_dir_with_all_configs ${dir}
done
clean_built_app_packages
clean_env

log_message "Cleaning finished."
